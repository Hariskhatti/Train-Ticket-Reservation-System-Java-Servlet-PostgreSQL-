package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/CheckSeatAvailabilityServlet")
public class CheckSeatAvailabilityServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html><html><head><title>Check Seat Availability</title>");
        out.println("<style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 40px; }");
        out.println("table { width: 100%; border-collapse: collapse; background: white; margin-top: 20px; }");
        out.println("th, td { padding: 12px; border: 1px solid #ccc; text-align: left; }");
        out.println("th { background-color: #003366; color: white; }");
        out.println("tr:hover { background-color: #f2f2f2; }");
        out.println(".btn { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #003366; color: white; text-decoration: none; border-radius: 6px; }");
        out.println(".btn:hover { background-color: #002855; }");
        out.println("</style></head><body>");

        out.println("<h2>Train Seat Availability</h2>");

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "SELECT ts.schedule_id, t.train_name, t.source_station, t.destination_station, ts.travel_date, ts.total_seats, " +
                         "COALESCE(SUM(b.seats_booked), 0) AS booked_seats, " +
                         "(ts.total_seats - COALESCE(SUM(b.seats_booked), 0)) AS remaining_seats " +
                         "FROM train_schedule ts " +
                         "JOIN trains t ON ts.train_id = t.train_id " +
                         "LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id " +
                         "GROUP BY ts.schedule_id, t.train_name, t.source_station, t.destination_station, ts.travel_date, ts.total_seats " +
                         "ORDER BY ts.travel_date";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            out.println("<table><tr>");
            out.println("<th>Train Name</th><th>Source</th><th>Destination</th><th>Date</th>");
            out.println("<th>Total Seats</th><th>Booked</th><th>Remaining</th><th>Action</th>");
            out.println("</tr>");

            while (rs.next()) {
                int scheduleId = rs.getInt("schedule_id");
                String trainName = rs.getString("train_name");
                String source = rs.getString("source_station");
                String destination = rs.getString("destination_station");
                String date = rs.getString("travel_date");
                int total = rs.getInt("total_seats");
                int booked = rs.getInt("booked_seats");
                int remaining = rs.getInt("remaining_seats");

                out.println("<tr>");
                out.println("<td>" + trainName + "</td>");
                out.println("<td>" + source + "</td>");
                out.println("<td>" + destination + "</td>");
                out.println("<td>" + date + "</td>");
                out.println("<td>" + total + "</td>");
                out.println("<td>" + booked + "</td>");
                out.println("<td>" + remaining + "</td>");
                out.println("<td>");
                out.println("<form action='BookTicketServlet' method='post'>");
                out.println("<input type='hidden' name='schedule_id' value='" + scheduleId + "'>");
                out.println("<input type='hidden' name='train_name' value='" + trainName + "'>");
                out.println("<input type='hidden' name='travel_date' value='" + date + "'>");
                out.println("<input type='hidden' name='source_station' value='" + source + "'>");
                out.println("<input type='hidden' name='destination_station' value='" + destination + "'>");
                out.println("<button type='submit'>Book</button>");
                out.println("</form>");
                out.println("</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("<br><a href='UserDashboardServlet' class='btn'>Back to Dashboard</a>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }

        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        doGet(request, response);
    }
}
