package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;

@WebServlet("/BookTicketServlet")
public class BookTicketServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int userId = (int) session.getAttribute("user_id");

        String trainName = request.getParameter("train_name") != null ? request.getParameter("train_name") : "";
        String source = request.getParameter("source_station") != null ? request.getParameter("source_station") : "";
        String destination = request.getParameter("destination_station") != null ? request.getParameter("destination_station") : "";
        String travelDate = request.getParameter("travel_date") != null ? request.getParameter("travel_date") : "";
        String scheduleId = request.getParameter("schedule_id") != null ? request.getParameter("schedule_id") : "";

        out.println("<!DOCTYPE html><html><head><title>Book Ticket</title><style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 40px; }");
        out.println(".form-box { background: white; padding: 30px; max-width: 550px; margin: auto; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }");
        out.println("h2 { text-align: center; color: #003366; margin-bottom: 25px; }");
        out.println("input, button { width: 100%; padding: 12px; margin-top: 10px; border: 1px solid #ccc; border-radius: 6px; font-size: 15px; }");
        out.println("button { background-color: #003366; color: white; cursor: pointer; }");
        out.println("button:hover { background-color: #002855; }");
        out.println("</style></head><body>");

        out.println("<div class='form-box'><h2>Ticket Booking</h2>");
        out.println("<form method='post' action='ProcessPayment'>");

        out.println("<input type='text' name='train_name' placeholder='Train Name' value='" + trainName + "' required>");
        out.println("<input type='text' name='source_station' placeholder='Source Station' value='" + source + "' required>");
        out.println("<input type='text' name='destination_station' placeholder='Destination Station' value='" + destination + "' required>");
        out.println("<input type='date' name='travel_date' value='" + travelDate + "' required>");
        out.println("<input type='number' name='seats_booked' placeholder='Number of Seats' min='1' required>");

        out.println("<input type='hidden' name='schedule_id' value='" + scheduleId + "'>");
        out.println("<input type='hidden' name='user_id' value='" + userId + "'>");

        out.println("<button type='submit'>Proceed to Payment</button>");
        out.println("</form></div></body></html>");
    }

    // ✅ Fix for 405 error
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
