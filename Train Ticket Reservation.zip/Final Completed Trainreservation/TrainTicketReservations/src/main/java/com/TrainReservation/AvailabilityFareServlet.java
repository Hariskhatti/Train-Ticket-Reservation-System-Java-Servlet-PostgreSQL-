package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/AvailabilityFareServlet")
public class AvailabilityFareServlet extends HttpServlet {
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        res.setContentType("text/html;charset=UTF-8");
        PrintWriter out = res.getWriter();

        String source = req.getParameter("source").trim();
        String dest = req.getParameter("destination").trim();
        String date = req.getParameter("travel_date");

        if (source.isEmpty() || dest.isEmpty() || date.isEmpty()) {
            out.println("<script>alert('Fill all fields'); window.location='availability_fare.html';</script>");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql =
            	    "SELECT t.train_number, t.train_name, ts.schedule_id, " +
            	    "t.departure_time, t.arrival_time, t.fare, ts.total_seats, " +
            	    "COALESCE(SUM(b.seats_booked), 0) AS booked " +
            	    "FROM train_schedule ts " +
            	    "JOIN trains t ON ts.train_id = t.train_id " +
            	    "LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id " +
            	    "WHERE t.source_station = ? AND t.destination_station = ? AND ts.travel_date = ? " +
            	    "GROUP BY t.train_number, t.train_name, ts.schedule_id, " +
            	    "t.departure_time, t.arrival_time, t.fare, ts.total_seats " +
            	    "ORDER BY t.departure_time";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, source);
            ps.setString(2, dest);
            ps.setDate(3, Date.valueOf(date));

            ResultSet rs = ps.executeQuery();

            out.println("<html><head><title>Available Trains</title>");
            out.println("<style>body{font-family:Segoe UI; padding:30px;} table{width:100%;border-collapse:collapse;} th,td{padding:10px;border:1px solid #ccc;text-align:center;} th{background:#003366;color:white;} button{padding:6px 12px;border:none;background:#003366;color:white;border-radius:4px;cursor:pointer;} button:hover{background:#002855;}</style>");
            out.println("</head><body><h2>Trains on " + date + " from " + source + " to " + dest + "</h2>");

            out.println("<table><tr><th>No.</th><th>Train #</th><th>Name</th><th>Dep</th><th>Arr</th><th>Fare</th><th>Avail</th><th>Book</th></tr>");

            int count = 0;
            while (rs.next()) {
                count++;
                int schedId = rs.getInt("schedule_id");
                int total = rs.getInt("total_seats");
                int booked = rs.getInt("booked");
                int avail = total - booked;

                out.println("<tr>");
                out.println("<td>" + count + "</td>");
                out.println("<td>" + rs.getString("train_number") + "</td>");
                out.println("<td>" + rs.getString("train_name") + "</td>");
                out.println("<td>" + rs.getTime("departure_time") + "</td>");
                out.println("<td>" + rs.getTime("arrival_time") + "</td>");
                out.println("<td>" + rs.getDouble("fare") + "</td>");
                out.println("<td>" + avail + "</td>");

                // BOOK FORM
                out.println("<td>");
                out.println("<form method='post' action='BookTicketServlet'>");
                out.println("<input type='hidden' name='schedule_id' value='" + schedId + "'>");
                out.println("<input type='hidden' name='train_name' value='" + rs.getString("train_name") + "'>");
                out.println("<input type='hidden' name='travel_date' value='" + date + "'>");
                out.println("<input type='hidden' name='source_station' value='" + source + "'>");
                out.println("<input type='hidden' name='destination_station' value='" + dest + "'>");
                out.println("<button type='submit'>Book</button>");
                out.println("</form>");
                out.println("</td>");

                out.println("</tr>");
            }

            out.println("</table>");

            if (count == 0) {
                out.println("<p style='color:red;'>No trains found.</p>");
            }

            out.println("<br><a href='UserDashboardServlet' style='display:inline-block;padding:10px 20px;background:#003366;color:white;text-decoration:none;border-radius:6px;'>Back to Dashboard</a>");

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
        }

        out.println("</body></html>");
    }
}
