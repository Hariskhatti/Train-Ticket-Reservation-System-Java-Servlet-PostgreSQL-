package com.TrainReservation;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/UserDashboardServlet")
public class UserDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        String userName = "User";

        if (session != null && session.getAttribute("userName") != null) {
            userName = (String) session.getAttribute("userName");
        } else {
            // Session expired or invalid
            out.println("<script>alert('Session expired. Please login again.'); window.location='user_login.html';</script>");
            return;
        }

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>User Dashboard</title><meta charset='UTF-8'>");
        out.println("<style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 50px; }");
        out.println(".dashboard { background: white; padding: 30px; max-width: 500px; margin: auto; border-radius: 12px; box-shadow: 0 3px 12px rgba(0,0,0,0.1); text-align: center; }");
        out.println(".dashboard h2 { color: #003366; margin-bottom: 25px; }");
        out.println(".dashboard a { display: block; margin: 10px auto; padding: 10px 20px; background-color: #003366; color: white; text-decoration: none; border-radius: 6px; font-size: 15px; width: 80%; transition: background-color 0.3s, transform 0.2s; }");
        out.println(".dashboard a:hover { background-color: #002855; transform: scale(1.02); }");
        out.println("</style></head><body>");

        out.println("<div class='dashboard'>");
        out.println("<h2>Welcome, " + userName + "</h2>");
        out.println("<a href='ViewUserTrainsServlet'>View Trains</a>");
        out.println("<a href='CheckSeatAvailabilityServlet'>Check Seat Availability</a>");
        out.println("<a href='availability_fare.html'>Train Availability & Fare</a>");
        out.println("<a href='BookTicketServlet'>Book Tickets</a>");
        out.println("<a href='CancelTicketServlet'>Cancel Booked Tickets</a>");
        out.println("<a href='BookingHistoryServlet'>View Booking History</a>");
        out.println("<a href='ViewUserProfileServlet'>View Profile</a>");
        out.println("<a href='UpdateUserProfileServlet'>Update Profile</a>");
        out.println("<a href='ChangePasswordServlet'>Change Password</a>");
        out.println("<a href='UserLogoutServlet'>Logout</a>");
        out.println("</div>");

        out.println("</body></html>");
    }
}
