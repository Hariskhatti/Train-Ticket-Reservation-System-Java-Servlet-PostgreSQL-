package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/DeleteUserServlet")
public class DeleteUserServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
		    throws ServletException, IOException {

		    response.setContentType("text/html");
		    PrintWriter out = response.getWriter();

		    HttpSession session = request.getSession(false);
		    if (session == null || session.getAttribute("adminName") == null) {
		        response.sendRedirect("admin_login.html");
		        return;
		    }

		    out.println("<!DOCTYPE html>");
		    out.println("<html><head><title>Delete User</title>");
		    out.println("<style>");
		    out.println("body { background-color: #eaf2fd; font-family: 'Segoe UI', sans-serif; margin: 0; padding: 0; }");
		    out.println(".container { max-width: 400px; margin: 80px auto; background-color: #fff; padding: 30px; border-radius: 16px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); }");
		    out.println("h2 { text-align: center; color: #003366; margin-bottom: 25px; }");
		    out.println("input[type='email'] { width: 100%; padding: 12px; margin: 10px 0; border-radius: 8px; border: 1px solid #ccc; font-size: 15px; }");
		    out.println("input[type='submit'], .btn-link { width: 100%; padding: 12px; margin-top: 15px; background-color: #003366; color: white; border: none; border-radius: 10px; cursor: pointer; font-size: 16px; font-weight: bold; }");
		    out.println("input[type='submit']:hover, .btn-link:hover { background-color: #002855; }");
		    out.println(".btn-link { display: block; text-align: center; text-decoration: none; }");
		    out.println("</style>");
		    out.println("</head><body>");

		    out.println("<div class='container'>");
		    out.println("<h2>Delete User</h2>");
		    out.println("<form method='post'>");
		    out.println("<input type='email' name='email' placeholder='Enter User Email' required>");
		    out.println("<input type='submit' value='Delete User'>");
		    out.println("</form>");
		    out.println("<a class='btn-link' href='AdminDashboardServlet'>Back to Dashboard</a>");
		    out.println("</div>");

		    out.println("</body></html>");
		}

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String email = request.getParameter("email");

        try {
            Connection conn = DBConnection.getConnection();

            String checkUser = "SELECT user_id FROM users WHERE email = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkUser);
            checkStmt.setString(1, email);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("user_id");

                String deleteSQL = "DELETE FROM users WHERE user_id = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteSQL);
                deleteStmt.setInt(1, userId);
                deleteStmt.executeUpdate();

                out.println("<script>");
                out.println("alert(' User deleted successfully.');");
                out.println("window.location.href = 'DeleteUserServlet';");
                out.println("</script>");

                deleteStmt.close();
            } else {
                out.println("<script>");
                out.println("alert(' User with this email not found.');");
                out.println("window.location.href = 'DeleteUserServlet';");
                out.println("</script>");
            }

            rs.close();
            checkStmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script>");
            out.println("alert(' Error: " + e.getMessage().replace("'", "\\'") + "');");
            out.println("window.location.href = 'DeleteUserServlet';");
            out.println("</script>");
        }
    }
}
