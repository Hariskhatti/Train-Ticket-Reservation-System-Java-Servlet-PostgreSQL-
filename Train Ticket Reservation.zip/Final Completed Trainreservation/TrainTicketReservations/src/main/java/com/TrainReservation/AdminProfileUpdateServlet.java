package com.TrainReservation;


import com.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/AdminProfileUpdateServlet")
public class AdminProfileUpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String newUsername = request.getParameter("username");
        String fullName = request.getParameter("fullname");
        String newPassword = request.getParameter("password");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminId") == null) {
            out.println("<script>alert('Session expired. Please login again.'); window.location='AdminLogin.html';</script>");
            return;
        }

        int adminId = (int) session.getAttribute("adminId");

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "UPDATE admins SET username = ?, password = ?, full_name = ? WHERE admin_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, newUsername);
            ps.setString(2, newPassword);
            ps.setString(3, fullName);
            ps.setInt(4, adminId);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                session.setAttribute("adminName", newUsername); // update session username
                out.println("<script>alert('Profile updated successfully'); window.location='AdminDashboardServlet';</script>");
            } else {
                out.println("<script>alert('Update failed'); window.location='admin_profile_update.html';</script>");
            }

            ps.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script>alert('Error: " + e.getMessage().replace("'", "") + "'); window.location='admin_profile_update.html';</script>");
        }
    }
}
