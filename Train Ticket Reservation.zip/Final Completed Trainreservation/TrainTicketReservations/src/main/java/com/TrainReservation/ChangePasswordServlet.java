package com.TrainReservation;

import com.util.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/ChangePasswordServlet")
public class ChangePasswordServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        String message = request.getParameter("message");

        out.println("<!DOCTYPE html><html><head><title>Change Password</title><style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 40px; }");
        out.println(".form-box { background: white; padding: 30px; max-width: 500px; margin: auto; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }");
        out.println("h2 { text-align: center; color: #003366; margin-bottom: 25px; }");
        out.println("input { width: 100%; padding: 12px; margin-top: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 6px; }");
        out.println("button { width: 100%; padding: 12px; background-color: #003366; color: white; font-size: 16px; border: none; border-radius: 6px; cursor: pointer; }");
        out.println("button:hover { background-color: #002855; }");
        out.println(".success { color: green; text-align: center; margin-bottom: 15px; }");
        out.println(".error { color: red; text-align: center; margin-bottom: 15px; }");
        out.println(".back-btn { text-align: center; margin-top: 20px; }");
        out.println(".back-btn a { display: inline-block; padding: 12px 24px; background-color: #003366; color: white; border-radius: 6px; text-decoration: none; font-size: 16px; }");
        out.println(".back-btn a:hover { background-color: #002855; }");
        out.println("</style></head><body>");

        out.println("<div class='form-box'><h2>Change Password</h2>");
        if ("success".equals(message)) {
            out.println("<div class='success'>Password changed successfully!</div>");
        } else if ("fail".equals(message)) {
            out.println("<div class='error'>Incorrect current password!</div>");
        }

        out.println("<form method='post' action='ChangePasswordServlet'>");
        out.println("<input type='password' name='current_password' placeholder='Current Password' required>");
        out.println("<input type='password' name='new_password' placeholder='New Password' required>");
        out.println("<button type='submit'>Change Password</button>");
        out.println("</form>");

        out.println("<div class='back-btn'><a href='UserDashboardServlet'>Back to Dashboard</a></div>");
        out.println("</div></body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        String currentPassword = request.getParameter("current_password");
        String newPassword = request.getParameter("new_password");

        try {
            Connection conn = DBConnection.getConnection();

            PreparedStatement ps = conn.prepareStatement("SELECT password FROM users WHERE user_id = ?");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next() && rs.getString("password").equals(currentPassword)) {
                PreparedStatement update = conn.prepareStatement("UPDATE users SET password = ? WHERE user_id = ?");
                update.setString(1, newPassword);
                update.setInt(2, userId);
                update.executeUpdate();
                update.close();
                response.sendRedirect("ChangePasswordServlet?message=success");
            } else {
                response.sendRedirect("ChangePasswordServlet?message=fail");
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}
