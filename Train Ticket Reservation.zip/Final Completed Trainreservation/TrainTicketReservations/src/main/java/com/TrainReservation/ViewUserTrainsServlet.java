package com.TrainReservation;

import com.util.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/ViewUserTrainsServlet")
public class ViewUserTrainsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT * FROM trains ORDER BY train_number";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            out.println("<html><head><title>View Trains</title>");
            out.println("<style>");
            out.println("body{font-family: 'Segoe UI', sans-serif; background-color: #f0f4ff; padding: 30px;}");
            out.println(".container{max-width: 1000px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1);}");
            out.println("h2{text-align: center; color: #003366; margin-bottom: 20px;}");
            out.println("table{width: 100%; border-collapse: collapse; margin-bottom: 20px;}");
            out.println("th, td{padding: 12px; text-align: left; border-bottom: 1px solid #ccc;}");
            out.println("th{background-color: #002B5B; color: white;}");
            out.println("tr:hover{background-color: #f2f2f2;}");
            out.println(".back-btn{display: inline-block; padding: 10px 20px; background-color: #003366; color: white; text-decoration: none; border-radius: 5px;}");
            out.println(".back-btn:hover{background-color: #002244;}");
            out.println("</style></head><body>");

            out.println("<div class='container'>");
            out.println("<h2>Available Trains</h2>");

            out.println("<table>");
            out.println("<tr><th>Train Number</th><th>Name</th><th>Source</th><th>Destination</th><th>Departure</th><th>Arrival</th><th>Seats</th><th>Fare</th></tr>");

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getString("train_number") + "</td>");
                out.println("<td>" + rs.getString("train_name") + "</td>");
                out.println("<td>" + rs.getString("source_station") + "</td>");
                out.println("<td>" + rs.getString("destination_station") + "</td>");
                out.println("<td>" + rs.getString("departure_time") + "</td>");
                out.println("<td>" + rs.getString("arrival_time") + "</td>");
                out.println("<td>" + rs.getInt("total_seats") + "</td>");
                out.println("<td>" + rs.getInt("fare") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("<a class='back-btn' href='UserDashboardServlet'>Back to Dashboard</a>");
            out.println("</div></body></html>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error fetching train data: " + e.getMessage() + "</p>");
        }
    }
}
