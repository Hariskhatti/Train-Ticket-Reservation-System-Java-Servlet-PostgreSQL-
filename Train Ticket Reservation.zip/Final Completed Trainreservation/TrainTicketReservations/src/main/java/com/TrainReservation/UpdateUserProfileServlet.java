package com.TrainReservation;

import com.util.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/UpdateUserProfileServlet")
public class UpdateUserProfileServlet extends HttpServlet {

    // Escape HTML utility
    private String escapeHtml(String input) {
        if (input == null) return "";
        return input.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#x27;");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        String message = request.getParameter("message");

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement("SELECT * FROM users WHERE user_id = ?");
            ps.setInt(1, userId);
            rs = ps.executeQuery();

            if (rs.next()) {
                out.println("<!DOCTYPE html><html><head><title>Update Profile</title><style>");
                out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 40px; }");
                out.println(".form-box { background: white; padding: 30px; max-width: 500px; margin: auto; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }");
                out.println("h2 { text-align: center; color: #003366; margin-bottom: 25px; }");
                out.println("input { width: 100%; padding: 12px; margin-top: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 6px; }");
                out.println("button, .btn { width: 100%; padding: 12px; background-color: #003366; color: white; font-size: 16px; border: none; border-radius: 6px; text-align: center; text-decoration: none; display: block; }");
                out.println("button:hover, .btn:hover { background-color: #002855; }");
                out.println(".success { color: green; text-align: center; margin-bottom: 15px; }");
                out.println("</style></head><body>");
                out.println("<div class='form-box'><h2>Update Profile</h2>");

                if ("success".equals(message)) {
                    out.println("<div class='success'>Profile Updated Successfully!</div>");
                }

                out.println("<form method='post' action='UpdateUserProfileServlet'>");
                out.println("<input type='text' name='full_name' value='" + escapeHtml(rs.getString("full_name")) + "' required>");
                out.println("<input type='email' name='email' value='" + escapeHtml(rs.getString("email")) + "' required>");
                out.println("<input type='text' name='phone' value='" + escapeHtml(rs.getString("phone")) + "' required>");
                out.println("<button type='submit'>Update Profile</button>");
                out.println("</form>");
                out.println("<br><a class='btn' href='UserDashboardServlet'>Back to Dashboard</a>");
                out.println("</div></body></html>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p style='color:red; text-align:center;'>Something went wrong. Please try again later.</p>");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        String fullName = request.getParameter("full_name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DBConnection.getConnection();
            ps = conn.prepareStatement("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE user_id = ?");
            ps.setString(1, fullName);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setInt(4, userId);

            ps.executeUpdate();

            response.sendRedirect("UpdateUserProfileServlet?message=success");

        } catch (Exception e) {
            e.printStackTrace();
            PrintWriter out = response.getWriter();
            response.setContentType("text/html");
            out.println("<p style='color:red; text-align:center;'>Update failed. Please try again.</p>");
        } finally {
            try { if (ps != null) ps.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }
    }
}
