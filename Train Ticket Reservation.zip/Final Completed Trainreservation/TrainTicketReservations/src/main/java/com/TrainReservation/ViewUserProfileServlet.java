package com.TrainReservation;

import com.util.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/ViewUserProfileServlet")
public class ViewUserProfileServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        Connection conn = null;

        try {
            conn = DBConnection.getConnection();

            out.println("<!DOCTYPE html>");
            out.println("<html><head><title>User Profile</title><style>");
            out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 40px; }");
            out.println(".profile-box { background: white; padding: 30px; max-width: 800px; margin: auto; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }");
            out.println("h2 { text-align: center; color: #003366; margin-bottom: 25px; }");
            out.println("p { font-size: 16px; color: #333; margin: 10px 0; }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 30px; }");
            out.println("th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }");
            out.println("th { background-color: #003366; color: white; }");
            out.println("tr:hover { background-color: #f9f9f9; }");
            out.println("a { display: block; margin-top: 30px; text-align: center; color: white; background-color: #003366; padding: 10px; border-radius: 6px; text-decoration: none; }");
            out.println("a:hover { background-color: #002855; }");
            out.println("</style></head><body>");

            out.println("<div class='profile-box'>");

            // 1. Fetch user details
            String userSql = "SELECT * FROM users WHERE user_id = ?";
            PreparedStatement ps1 = conn.prepareStatement(userSql);
            ps1.setInt(1, userId);
            ResultSet rs1 = ps1.executeQuery();

            if (rs1.next()) {
                out.println("<h2>Your Profile</h2>");
                out.println("<p><strong>Full Name:</strong> " + rs1.getString("full_name") + "</p>");
                out.println("<p><strong>Email:</strong> " + rs1.getString("email") + "</p>");
                out.println("<p><strong>Phone:</strong> " + rs1.getString("phone") + "</p>");
                out.println("<p><strong>Joined At:</strong> " + rs1.getTimestamp("created_at") + "</p>");
            } else {
                out.println("<p>User not found.</p>");
                out.println("<a href='UserDashboardServlet'>Back to Dashboard</a>");
                out.println("</div></body></html>");
                rs1.close();
                ps1.close();
                return;
            }

            rs1.close();
            ps1.close();

            // 2. Fetch booking history
            String bookingSql = "SELECT t.train_name, t.source_station, t.destination_station, " +
                    "ts.travel_date, b.seats_booked, b.booking_time " +
                    "FROM bookings b " +
                    "JOIN train_schedule ts ON b.schedule_id = ts.schedule_id " +
                    "JOIN trains t ON ts.train_id = t.train_id " +
                    "WHERE b.user_id = ? ORDER BY ts.travel_date DESC";
            PreparedStatement ps2 = conn.prepareStatement(bookingSql);
            ps2.setInt(1, userId);
            ResultSet rs2 = ps2.executeQuery();

            boolean hasBooking = false;

            out.println("<h2>Your Booked Tickets</h2>");
            out.println("<table>");
            out.println("<tr><th>Train Name</th><th>From</th><th>To</th><th>Travel Date</th><th>Seats</th><th>Booked At</th></tr>");

            while (rs2.next()) {
                hasBooking = true;
                out.println("<tr>");
                out.println("<td>" + rs2.getString("train_name") + "</td>");
                out.println("<td>" + rs2.getString("source_station") + "</td>");
                out.println("<td>" + rs2.getString("destination_station") + "</td>");
                out.println("<td>" + rs2.getDate("travel_date") + "</td>");
                out.println("<td>" + rs2.getInt("seats_booked") + "</td>");
                out.println("<td>" + rs2.getTimestamp("booking_time") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            if (!hasBooking) {
                out.println("<p style='margin-top:15px; color:gray; text-align:center;'>No tickets purchased yet.</p>");
            }

            rs2.close();
            ps2.close();

            out.println("<a href='UserDashboardServlet'>Back to Dashboard</a>");
            out.println("</div></body></html>");

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p style='color:red; text-align:center;'>An error occurred: " + e.getMessage() + "</p>");
            out.println("<a href='UserDashboardServlet'>Back to Dashboard</a>");
            out.println("</div></body></html>");
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
