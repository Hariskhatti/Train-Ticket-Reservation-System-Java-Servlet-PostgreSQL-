package com.TrainReservation;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/AdminDashboardServlet")
public class AdminDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin_login.html");
            return;
        }

        String adminName = (String) session.getAttribute("adminName");

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Admin Dashboard</title>");
        out.println("<meta charset='UTF-8'>");
        out.println("<style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 50px; }");
        out.println(".dashboard { background: white; padding: 30px; max-width: 450px; margin: auto; border-radius: 12px; box-shadow: 0 3px 12px rgba(0,0,0,0.1); text-align: center; }");
        out.println(".dashboard h2 { color: #003366; margin-bottom: 25px; }");
        out.println(".dashboard a { display: block; margin: 10px auto; padding: 10px 20px; background-color: #003366; color: white; text-decoration: none; border-radius: 6px; font-size: 15px; width: 80%; transition: background-color 0.3s, transform 0.2s; }");
        out.println(".dashboard a:hover { background-color: #002855; transform: scale(1.02); }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<div class='dashboard'>");
        out.println("<h2>Welcome, " + adminName + "</h2>");
        out.println("<a href='add_train.html'>Add Train</a>");
        out.println("<a href='ViewTrainsServlet'>View Trains</a>");
        out.println("<a href='UpdateTrainServlet'>Update Train</a>");
        out.println("<a href='delete_train.html'>Delete Train</a>");
        out.println("<a href='add_schedule.html'>Add Schedule</a>");
        out.println("<a href='ViewScheduleServlet'>View Schedule</a>");  // ✅ NEW button
        out.println("<a href='SeeReservationServlet'>See Ticket Reservations</a>");
        out.println("<a href='DeleteUserServlet'>Delete User</a>");
        out.println("<a href='Admin_Profile_Update.html'>Edit Profile</a>");
        out.println("<a href='AdminLogoutServlet'>Logout</a>");
        out.println("</div>");

        out.println("</body>");
        out.println("</html>");
    }
}
