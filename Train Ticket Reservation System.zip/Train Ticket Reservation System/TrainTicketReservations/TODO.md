# Train Ticket Reservation Project Updates

## 1. Update User Profile Page
- [x] Modify UpdateUserProfileServlet.java to add optional password field in the form
- [x] Add Logout button top-right in the profile update page
- [x] Implement conditional password update in doPost: only update if password is not empty

## 2. Unified Search Page
- [x] Create new PublicSearchServlet.java for unified search (merge CheckSchedule + CheckAvailability)
- [x] Add search form with fields: From (source), To (destination), Date
- [x] Display results with: Train, From, To, Date, Departure (source), Arrival (destination), Price, Available Seats, Book action
- [x] Make page public access (no login required)
- [x] Booking links redirect to user_login.html if not logged in
- [x] Update TrainHome.html to link to the new search page

## 3. Refactor View Schedule Page
- [x] Modify ViewScheduleServlet.java to move "Back to Dashboard" button higher (near top)
- [x] Move "Add Schedule" button to the right
- [x] Combine Train name and number in the same table row (e.g., "Express 123")

## 4. UI Cleanup
- [x] Ensure proper alignment of elements across all modified pages
- [x] Use consistent styling and Bootstrap classes where applicable
- [x] Test responsiveness and visual consistency

## Testing
- [x] Test profile update with and without password change
- [x] Test unified search functionality and booking redirects
- [x] Verify admin schedule view changes
- [x] Check UI alignment on different screen sizes
