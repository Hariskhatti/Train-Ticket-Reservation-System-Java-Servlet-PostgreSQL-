package com.TrainReservation;

import com.util.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/ViewTrainsServlet")
public class ViewTrainsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT * FROM trains ORDER BY train_number";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            out.println("<html><head><title>View Trains</title>");
            out.println("<style>");
            out.println("body { font-family: 'Segoe UI', sans-serif; background-color: #f0f4ff; padding: 30px; }");
            out.println(".button-panel {");
            out.println("  background: white;");
            out.println("  padding: 20px;");
            out.println("  max-width: 750px;");
            out.println("  margin: 0 auto 30px auto;");
            out.println("  border-radius: 10px;");
            out.println("  box-shadow: 0 4px 12px rgba(0,0,0,0.1);");
            out.println("  display: flex;");
            out.println("  flex-wrap: wrap;");
            out.println("  gap: 10px;");
            out.println("  justify-content: center;");
            out.println("}");
            out.println(".button-panel a {");
            out.println("  padding: 10px 18px;");
            out.println("  background-color: #003366;");
            out.println("  color: white;");
            out.println("  text-decoration: none;");
            out.println("  border-radius: 6px;");
            out.println("  transition: background-color 0.3s, transform 0.2s;");
            out.println("}");
            out.println(".button-panel a:hover {");
            out.println("  background-color: #002855;");
            out.println("  transform: scale(1.03);");
            out.println("}");

            out.println(".search-box { text-align: center; margin-bottom: 20px; }");
            out.println(".search-box input { width: 300px; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }");
            out.println("table { width: 100%; border-collapse: collapse; background: white; }");
            out.println("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }");
            out.println("th { background-color: #002B5B; color: white; }");
            out.println("tr:hover { background-color: #f5f5f5; }");
            out.println("</style>");

            // JS for search
            out.println("<script>");
            out.println("function filterTable() {");
            out.println("  var input = document.getElementById('searchInput');");
            out.println("  var filter = input.value.toLowerCase();");
            out.println("  var table = document.getElementById('trainTable');");
            out.println("  var tr = table.getElementsByTagName('tr');");
            out.println("  for (var i = 1; i < tr.length; i++) {");
            out.println("    var tdText = tr[i].innerText.toLowerCase();");
            out.println("    tr[i].style.display = tdText.includes(filter) ? '' : 'none';");
            out.println("  }");
            out.println("}");
            out.println("</script>");

            out.println("</head><body>");
            out.println("<h2 style='text-align:center; color:#003366;'>Train Management Panel</h2>");

            // Fancy Button Panel
            out.println("<div class='button-panel'>");
            out.println("<a href='add_train.html'> Add Train</a>");
            out.println("<a href='UpdateTrainServlet'> Update Train</a>");
            out.println("<a href='delete_train.html'> Delete Train</a>");
            out.println("<a href='AdminDashboardServlet'> Back to Dashboard</a>");
            out.println("</div>");

            // Search bar
            out.println("<div class='search-box'>");
            out.println("<input type='text' id='searchInput' onkeyup='filterTable()' placeholder='Search by train number, name, station...'>");
            out.println("</div>");

            // Table
            out.println("<table id='trainTable'>");
            out.println("<tr><th>Train Number</th><th>Name</th><th>Source</th><th>Destination</th><th>Departure</th><th>Arrival</th><th>Seats</th><th>Fare</th></tr>");

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getString("train_number") + "</td>");
                out.println("<td>" + rs.getString("train_name") + "</td>");
                out.println("<td>" + rs.getString("source_station") + "</td>");
                out.println("<td>" + rs.getString("destination_station") + "</td>");
                out.println("<td>" + rs.getString("departure_time") + "</td>");
                out.println("<td>" + rs.getString("arrival_time") + "</td>");
                out.println("<td>" + rs.getInt("total_seats") + "</td>");
                out.println("<td>" + rs.getInt("fare") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error fetching trains: " + e.getMessage() + "</p>");
        }
    }
}
