package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/PublicLandingPageServlet")
public class PublicLandingPageServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String from = request.getParameter("from");
        String to = request.getParameter("to");
        String date = request.getParameter("date");

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Find Train</title>");

        out.println("<style>");
        out.println("body { background:#eef3ff; font-family:'Segoe UI',sans-serif; padding:30px; }");
        out.println(".box { max-width:1100px; margin:auto; background:white; padding:28px; border-radius:14px; box-shadow:0 4px 15px rgba(0,0,0,0.12); }");
        out.println("h2 { text-align:center; font-weight:700; color:#002b5b; margin-bottom:25px; }");
        out.println("label { font-weight:600; margin-top:10px; display:block; }");
        out.println("input { width:100%; padding:12px; border-radius:6px; border:1px solid #bbb; margin-top:5px; font-size:15px; }");
        out.println(".btn { background:#002b5b; color:white; padding:12px; width:100%; margin-top:20px; border:none; border-radius:6px; font-size:17px; cursor:pointer; }");
        out.println(".btn:hover { background:#001f3f; }");
        out.println("table { width:100%; border-collapse:collapse; margin-top:30px; }");
        out.println("th { background:#002b5b; color:white; padding:12px; font-size:15px; }");
        out.println("td { padding:12px; text-align:center; border-bottom:1px solid #ccc; font-size:15px; }");
        out.println("tr:hover { background:#f4f7ff; }");
        out.println(".book-btn { background:#28a745; color:white; padding:7px 12px; text-decoration:none; border-radius:5px; }");
        out.println(".book-btn:hover { background:#1e7e34; }");
        out.println("</style>");

        out.println("</head>");
        out.println("<body>");

        out.println("<div class='box'>");

        out.println("<h2>Find Your Train</h2>");

        // ---------------- SEARCH FORM ----------------
        out.println("<form method='GET' action='PublicLandingPageServlet'>");

        out.println("<label>From Station</label>");
        out.println("<input type='text' name='from' required value='" + (from != null ? from : "") + "'>");

        out.println("<label>To Station</label>");
        out.println("<input type='text' name='to' required value='" + (to != null ? to : "") + "'>");

        out.println("<label>Travel Date</label>");
        out.println("<input type='date' name='date' required value='" + (date != null ? date : "") + "'>");

        out.println("<button class='btn'>Search Trains</button>");
        out.println("</form>");

        // ---------------- SEARCH RESULT SECTION ----------------
        if (from != null && to != null && date != null) {

            try {
                Connection conn = DBConnection.getConnection();

                String sql =
                        "SELECT t.train_id, t.train_number, t.train_name, t.source_station, t.destination_station, " +
                        "t.departure_time, t.arrival_time, t.fare, " +
                        "ts.schedule_id, ts.travel_date, ts.total_seats, " +
                        "(ts.total_seats - COALESCE(SUM(b.seats_booked),0)) AS remaining_seats " +
                        "FROM trains t " +
                        "JOIN train_schedule ts ON t.train_id = ts.train_id " +
                        "LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id " +
                        "WHERE LOWER(t.source_station)=LOWER(?) " +
                        "AND LOWER(t.destination_station)=LOWER(?) " +
                        "AND ts.travel_date=? " +
                        "GROUP BY t.train_id, t.train_number, t.train_name, " +
                        "t.source_station, t.destination_station, t.departure_time, t.arrival_time, " +
                        "t.fare, ts.schedule_id, ts.travel_date, ts.total_seats " +
                        "ORDER BY t.train_number";

                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, from);
                ps.setString(2, to);
                ps.setDate(3, java.sql.Date.valueOf(date));

                ResultSet rs = ps.executeQuery();

                out.println("<table>");
                out.println("<tr>");
                out.println("<th>Train No</th>");
                out.println("<th>Name</th>");
                out.println("<th>From</th>");
                out.println("<th>To</th>");
                out.println("<th>Date</th>");
                out.println("<th>Departure</th>");
                out.println("<th>Arrival</th>");
                out.println("<th>Fare</th>");
                out.println("<th>Total Seats</th>");
                out.println("<th>Remaining</th>");
                out.println("<th>Action</th>");
                out.println("</tr>");

                boolean found = false;

                while (rs.next()) {
                    found = true;

                    out.println("<tr>");
                    out.println("<td>" + rs.getString("train_number") + "</td>");
                    out.println("<td>" + rs.getString("train_name") + "</td>");
                    out.println("<td>" + rs.getString("source_station") + "</td>");
                    out.println("<td>" + rs.getString("destination_station") + "</td>");
                    out.println("<td>" + rs.getDate("travel_date") + "</td>");
                    out.println("<td>" + rs.getString("departure_time") + "</td>");
                    out.println("<td>" + rs.getString("arrival_time") + "</td>");
                    out.println("<td>Rs. " + rs.getDouble("fare") + "</td>");
                    out.println("<td>" + rs.getInt("total_seats") + "</td>");
                    out.println("<td>" + rs.getInt("remaining_seats") + "</td>");
                    out.println("<td><a class='book-btn' href='user_login.html'>Book</a></td>");
                    out.println("</tr>");
                }

                if (!found) {
                    out.println("<tr><td colspan='11' style='color:red;'>No trains available on this route.</td></tr>");
                }

                out.println("</table>");

                rs.close();
                ps.close();
                conn.close();

            } catch (Exception e) {
                out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            }
        }

        out.println("</div>"); // end box

        out.println("</body>");
        out.println("</html>");
    }
}
