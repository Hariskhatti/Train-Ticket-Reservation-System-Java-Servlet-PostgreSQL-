package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/ViewScheduleServlet")
public class ViewScheduleServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin_login.html");
            return;
        }

        out.println("<!DOCTYPE html><html><head><title>Train Schedules</title>");
        out.println("<style>");
        out.println("body { font-family: 'Segoe UI', sans-serif; background-color: #e8f0fe; padding: 40px; }");
        out.println("h2 { color: #003366; margin-bottom: 25px; }");
        out.println(".btn { padding: 10px 20px; background-color: #003366; color: white; text-decoration: none; border: none; border-radius: 6px; font-size: 15px; transition: background-color 0.3s, transform 0.2s; cursor: pointer; }");
        out.println(".btn:hover { background-color: #002855; transform: scale(1.02); }");
        out.println(".delete-btn { background-color: #d9534f; }");
        out.println(".delete-btn:hover { background-color: #c9302c; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-bottom: 40px; background: white; }");
        out.println("th, td { padding: 12px; border: 1px solid #ccc; text-align: left; }");
        out.println("th { background-color: #003366; color: white; }");
        out.println("tr:hover { background-color: #f1f1f1; }");
        out.println(".top-buttons { display: flex; justify-content: space-between; margin-bottom: 20px; }");
        out.println(".bottom-buttons { display: flex; justify-content: flex-end; margin-top: 40px; }");
        out.println("</style></head><body>");

        out.println("<div class='top-buttons'>");
        out.println("<a href='AdminDashboardServlet' class='btn'>Back to Dashboard</a>");
        out.println("<a href='add_schedule.html' class='btn'>Add Schedule</a>");
        out.println("</div>");

        out.println("<h2>Train Schedules</h2>");

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT ts.schedule_id, ts.travel_date, ts.total_seats, t.train_name, t.train_number, t.source_station, t.destination_station " +
                         "FROM train_schedule ts " +
                         "JOIN trains t ON ts.train_id = t.train_id " +
                         "ORDER BY t.train_name, ts.travel_date";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            out.println("<table>");
            out.println("<tr><th>Train No</th><th>Train Name</th><th>From</th><th>To</th><th>Travel Date</th><th>Total Seats</th><th>Action</th></tr>");

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getString("train_number") + "</td>");
                out.println("<td>" + rs.getString("train_name") + "</td>");
                out.println("<td>" + rs.getString("source_station") + "</td>");
                out.println("<td>" + rs.getString("destination_station") + "</td>");
                out.println("<td>" + rs.getDate("travel_date") + "</td>");
                out.println("<td>" + rs.getInt("total_seats") + "</td>");
                out.println("<td>");
                out.println("<form action='DeleteScheduleServlet' method='post' style='margin:0;'>");
                out.println("<input type='hidden' name='schedule_id' value='" + rs.getInt("schedule_id") + "'>");
                out.println("<input type='submit' class='btn delete-btn' value='Delete'>");
                out.println("</form>");
                out.println("</td>");
                out.println("</tr>");
            }

            out.println("</table>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }

        out.println("</body></html>");
    }
}
