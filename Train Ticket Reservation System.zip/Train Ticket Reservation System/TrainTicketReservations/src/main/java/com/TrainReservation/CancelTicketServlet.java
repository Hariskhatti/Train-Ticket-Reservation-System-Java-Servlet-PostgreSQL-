package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/CancelTicketServlet")
public class CancelTicketServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Cancel Tickets</title><style>");
        out.println("body{font-family:Segoe UI;background:#e8f0fe;padding:40px;}");
        out.println(".box{background:white;padding:30px;max-width:500px;margin:auto;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.1);}");
        out.println("input, select{width:100%;padding:12px;margin-top:10px;border:1px solid #ccc;border-radius:6px;}");
        out.println("button{width:100%;margin-top:15px;padding:12px;background:#003366;color:white;border:none;border-radius:6px;}");
        out.println("button:hover{background:#002855;}");
        out.println("</style></head><body>");
        out.println("<div class='box'>");
        out.println("<h2>Cancel Tickets</h2>");
        out.println("<form method='post' action='CancelTicketServlet'>");

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT b.booking_id, t.train_name, ts.travel_date, b.seats_booked " +
                         "FROM bookings b " +
                         "JOIN train_schedule ts ON b.schedule_id = ts.schedule_id " +
                         "JOIN trains t ON ts.train_id = t.train_id " +
                         "WHERE b.user_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            out.println("<select name='booking_id' required>");
            while (rs.next()) {
                int bookingId = rs.getInt("booking_id");
                String train = rs.getString("train_name");
                String date = rs.getString("travel_date");
                int seats = rs.getInt("seats_booked");
                out.println("<option value='" + bookingId + "'>" + train + " | " + date + " | Seats: " + seats + "</option>");
            }
            out.println("</select>");
            out.println("<input type='number' name='cancel_seats' placeholder='Number of tickets to cancel' min='1' required>");
            out.println("<button type='submit'>Cancel Tickets</button>");
            out.println("</form></div></body></html>");

            rs.close(); ps.close(); conn.close();

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        int bookingId = Integer.parseInt(request.getParameter("booking_id"));
        int cancelSeats = Integer.parseInt(request.getParameter("cancel_seats"));

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();

            // Get current booking info
            String getSql = "SELECT b.seats_booked, ts.schedule_id, ts.train_id " +
                            "FROM bookings b " +
                            "JOIN train_schedule ts ON b.schedule_id = ts.schedule_id " +
                            "WHERE b.booking_id = ? AND b.user_id = ?";
            PreparedStatement getPs = conn.prepareStatement(getSql);
            getPs.setInt(1, bookingId);
            getPs.setInt(2, userId);
            ResultSet rs = getPs.executeQuery();

            if (rs.next()) {
                int currentSeats = rs.getInt("seats_booked");
                int scheduleId = rs.getInt("schedule_id");
                int trainId = rs.getInt("train_id");

                if (cancelSeats > currentSeats) {
                    out.println("<script>alert('Cannot cancel more seats than booked.'); history.back();</script>");
                    return;
                }

                // Get fare from trains table
                String fareSql = "SELECT fare FROM trains WHERE train_id = ?";
                PreparedStatement farePs = conn.prepareStatement(fareSql);
                farePs.setInt(1, trainId);
                ResultSet fareRs = farePs.executeQuery();
                fareRs.next();
                double fare = fareRs.getDouble("fare");
                fareRs.close();
                farePs.close();

                if (cancelSeats == currentSeats) {
                    // Full cancellation
                    PreparedStatement delPs = conn.prepareStatement("DELETE FROM bookings WHERE booking_id = ?");
                    delPs.setInt(1, bookingId);
                    delPs.executeUpdate();
                    delPs.close();
                } else {
                    // Partial cancellation
                    String updateSql = "UPDATE bookings SET seats_booked = seats_booked - ?, total_amount = total_amount - (? * ?) WHERE booking_id = ?";
                    PreparedStatement updatePs = conn.prepareStatement(updateSql);
                    updatePs.setInt(1, cancelSeats);
                    updatePs.setInt(2, cancelSeats);
                    updatePs.setDouble(3, fare);
                    updatePs.setInt(4, bookingId);
                    updatePs.executeUpdate();
                    updatePs.close();
                }

                rs.close(); getPs.close(); conn.close();

                out.println("<script>alert('Tickets cancelled successfully!'); window.location='UserDashboardServlet';</script>");

            } else {
                out.println("<script>alert('Booking not found.'); history.back();</script>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }
    }
}
