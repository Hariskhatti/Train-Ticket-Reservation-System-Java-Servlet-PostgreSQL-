package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/BookingHistoryServlet")
public class BookingHistoryServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");

        out.println("<!DOCTYPE html><html><head><title>Booking History</title>");
        out.println("<style>");
        out.println("body { font-family: 'Segoe UI', sans-serif; background-color: #e8f0fe; padding: 40px; }");
        out.println("table { width: 100%; border-collapse: collapse; background: white; }");
        out.println("th, td { padding: 12px; border: 1px solid #ccc; text-align: left; }");
        out.println("th { background-color: #003366; color: white; }");
        out.println("tr:hover { background-color: #f1f1f1; }");
        out.println(".btn { margin-top: 20px; display: inline-block; padding: 10px 20px; background: #003366; color: white; text-decoration: none; border-radius: 6px; }");
        out.println(".btn:hover { background: #002855; }");
        out.println("</style></head><body>");

        out.println("<h2>Booking History</h2>");
        out.println("<table>");
        out.println("<tr><th>Train</th><th>From</th><th>To</th><th>Travel Date</th><th>Status</th><th>Seats</th><th>Action Date</th></tr>");

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT t.train_name, t.source_station, t.destination_station, " +
                         "ts.travel_date, bh.action_type, bh.seats, bh.action_date " +
                         "FROM booking_history bh " +
                         "JOIN train_schedule ts ON bh.schedule_id = ts.schedule_id " +
                         "JOIN trains t ON ts.train_id = t.train_id " +
                         "WHERE bh.user_id = ? " +
                         "ORDER BY ts.travel_date DESC, bh.action_date DESC";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getString("train_name") + "</td>");
                out.println("<td>" + rs.getString("source_station") + "</td>");
                out.println("<td>" + rs.getString("destination_station") + "</td>");
                out.println("<td>" + rs.getDate("travel_date") + "</td>");
                out.println("<td>" + rs.getString("action_type") + "</td>");
                out.println("<td>" + rs.getInt("seats") + "</td>");
                out.println("<td>" + rs.getTimestamp("action_date") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("<a href='UserDashboardServlet' class='btn'>Back to Dashboard</a>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }

        out.println("</body></html>");
    }
}
