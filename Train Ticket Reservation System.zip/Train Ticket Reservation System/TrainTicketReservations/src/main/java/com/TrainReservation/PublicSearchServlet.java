package com.TrainReservation;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/PublicSearchServlet")
public class PublicSearchServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String source = request.getParameter("source");
        String destination = request.getParameter("destination");
        String date = request.getParameter("date");

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Search Trains</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'>");
        out.println("<link rel='stylesheet' href='css/train-theme.css'>");
        out.println("</head>");
        out.println("<body>");

        out.println("<div class='container'>");
        out.println("<div class='text-center mb-5'>");
        out.println("<h1 class='text-white mb-3'><i class='fas fa-search me-3'></i>Search Trains</h1>");
        out.println("<p class='text-white'>Find available trains and book your tickets</p>");
        out.println("<a href='TrainHome.html' class='btn-custom'><i class='fas fa-home me-2'></i>Back to Home</a>");
        out.println("</div>");

        // Search Form
        out.println("<div class='card mb-4'>");
        out.println("<div class='card-body'>");
        out.println("<form method='get' action='PublicSearchServlet' class='row g-3'>");
        out.println("<div class='col-md-3'>");
        out.println("<label for='source' class='form-label'>From</label>");
        out.println("<input type='text' class='form-control' id='source' name='source' value='" + (source != null ? source : "") + "' placeholder='Source Station'>");
        out.println("</div>");
        out.println("<div class='col-md-3'>");
        out.println("<label for='destination' class='form-label'>To</label>");
        out.println("<input type='text' class='form-control' id='destination' name='destination' value='" + (destination != null ? destination : "") + "' placeholder='Destination Station'>");
        out.println("</div>");
        out.println("<div class='col-md-3'>");
        out.println("<label for='date' class='form-label'>Date</label>");
        out.println("<input type='date' class='form-control' id='date' name='date' value='" + (date != null ? date : "") + "'>");
        out.println("</div>");
        out.println("<div class='col-md-3 d-flex align-items-end'>");
        out.println("<button type='submit' class='btn btn-primary w-100'><i class='fas fa-search me-2'></i>Search</button>");
        out.println("</div>");
        out.println("</form>");
        out.println("</div>");
        out.println("</div>");

        // Results
        if (source != null || destination != null || date != null) {
            try {
                Class.forName("org.postgresql.Driver");
                Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/traindb", "postgres", "password");

                StringBuilder query = new StringBuilder("SELECT ts.schedule_id, t.train_name, t.train_number, t.source_station, t.destination_station, ts.travel_date, ts.total_seats, ts.fare, ");
                query.append("COALESCE(SUM(b.seats_booked), 0) as booked_seats, ");
                query.append("(ts.total_seats - COALESCE(SUM(b.seats_booked), 0)) as available_seats ");
                query.append("FROM train_schedule ts ");
                query.append("JOIN trains t ON ts.train_id = t.train_id ");
                query.append("LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id ");
                query.append("WHERE 1=1 ");

                if (source != null && !source.trim().isEmpty()) {
                    query.append("AND LOWER(t.source_station) LIKE LOWER(?) ");
                }
                if (destination != null && !destination.trim().isEmpty()) {
                    query.append("AND LOWER(t.destination_station) LIKE LOWER(?) ");
                }
                if (date != null && !date.trim().isEmpty()) {
                    query.append("AND ts.travel_date = ? ");
                }

                query.append("GROUP BY ts.schedule_id, t.train_name, t.train_number, t.source_station, t.destination_station, ts.travel_date, ts.total_seats, ts.fare ");
                query.append("ORDER BY ts.travel_date, t.train_name");

                PreparedStatement ps = con.prepareStatement(query.toString());

                int paramIndex = 1;
                if (source != null && !source.trim().isEmpty()) {
                    ps.setString(paramIndex++, "%" + source.trim() + "%");
                }
                if (destination != null && !destination.trim().isEmpty()) {
                    ps.setString(paramIndex++, "%" + destination.trim() + "%");
                }
                if (date != null && !date.trim().isEmpty()) {
                    ps.setDate(paramIndex++, Date.valueOf(date));
                }

                ResultSet rs = ps.executeQuery();

                if (!rs.next()) {
                    out.println("<div class='alert alert-info text-center'>No trains found matching your criteria.</div>");
                } else {
                    out.println("<div class='card'>");
                    out.println("<div class='card-header'>");
                    out.println("<h4 class='mb-0'><i class='fas fa-list me-2'></i>Search Results</h4>");
                    out.println("</div>");
                    out.println("<div class='card-body'>");
                    out.println("<div class='table-responsive'>");
                    out.println("<table class='table table-striped'>");
                    out.println("<thead class='table-dark'>");
                    out.println("<tr>");
                    out.println("<th><i class='fas fa-train me-1'></i>Train</th>");
                    out.println("<th><i class='fas fa-route me-1'></i>From</th>");
                    out.println("<th><i class='fas fa-route me-1'></i>To</th>");
                    out.println("<th><i class='fas fa-calendar me-1'></i>Date</th>");
                    out.println("<th><i class='fas fa-clock me-1'></i>Departure</th>");
                    out.println("<th><i class='fas fa-clock me-1'></i>Arrival</th>");
                    out.println("<th><i class='fas fa-dollar-sign me-1'></i>Price</th>");
                    out.println("<th><i class='fas fa-chair me-1'></i>Available</th>");
                    out.println("<th><i class='fas fa-sign-in-alt me-1'></i>Action</th>");
                    out.println("</tr>");
                    out.println("</thead>");
                    out.println("<tbody>");

                    do {
                        int available = rs.getInt("available_seats");
                        String availabilityClass = available > 50 ? "availability-high" :
                                                 available > 20 ? "availability-medium" : "availability-low";

                        out.println("<tr>");
                        out.println("<td>" + rs.getString("train_name") + " (" + rs.getString("train_number") + ")</td>");
                        out.println("<td>" + rs.getString("source_station") + "</td>");
                        out.println("<td>" + rs.getString("destination_station") + "</td>");
                        out.println("<td>" + rs.getDate("travel_date") + "</td>");
                        out.println("<td>" + rs.getString("source_station") + "</td>"); // Placeholder for departure time
                        out.println("<td>" + rs.getString("destination_station") + "</td>"); // Placeholder for arrival time
                        out.println("<td>$" + rs.getDouble("fare") + "</td>");
                        out.println("<td class='" + availabilityClass + "'>" + available + "</td>");
                        if (available > 0) {
                            out.println("<td><a href='user_login.html' class='btn btn-sm btn-success'>Book Now</a></td>");
                        } else {
                            out.println("<td><span class='badge bg-danger'>Fully Booked</span></td>");
                        }
                        out.println("</tr>");
                    } while (rs.next());

                    out.println("</tbody>");
                    out.println("</table>");
                    out.println("</div>");
                    out.println("</div>");
                    out.println("</div>");
                }

                rs.close();
                ps.close();
                con.close();

            } catch (Exception e) {
                out.println("<div class='alert alert-danger'>Error: " + e.getMessage() + "</div>");
            }
        }

        out.println("</div>");
        out.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>");
        out.println("</body>");
        out.println("</html>");
    }
}
