package com.TrainReservation;

import com.util.DBConnection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/ViewAllTrainsForUserServlet")
public class ViewAllTrainsForUserServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // ===== LOGIN CHECK =====
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userName") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        String user = (String) session.getAttribute("userName");

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Available Trains</title>");

        // ---------- CSS ----------
        out.println("<style>");
        out.println("body { font-family: 'Segoe UI', sans-serif; background:#eef3ff; padding:40px; }");
        out.println(".container { max-width:1000px; margin:auto; background:white; padding:25px; border-radius:12px; box-shadow:0 3px 12px rgba(0,0,0,0.1);} ");
        out.println("h2 { color:#003366; text-align:center; margin-bottom:30px; }");
        out.println("table { width:100%; border-collapse:collapse; margin-top:20px; background:white; }");
        out.println("th, td { padding:12px; border:1px solid #ccc; text-align:center; }");
        out.println("th { background:#003366; color:white; }");
        out.println("tr:hover { background:#f1f4ff; }");
        out.println(".book-btn { background:#28a745; padding:8px 14px; color:white; border-radius:6px; text-decoration:none; }");
        out.println(".book-btn:hover { background:#1e7e34; }");
        out.println(".top { display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; }");
        out.println(".logout { background:#d9534f; padding:10px 18px; color:white; text-decoration:none; border-radius:6px; }");
        out.println(".logout:hover { background:#c9302c; }");
        out.println("</style>");

        out.println("</head><body>");
        out.println("<div class='container'>");

        // HEADER WITH LOGOUT
        out.println("<div class='top'>");
        out.println("<h2>All Available Trains</h2>");
        out.println("<a class='logout' href='UserLogoutServlet'>Logout</a>");
        out.println("</div>");

        try {
            Connection conn = DBConnection.getConnection();

            String sql =
                    "SELECT t.train_id, t.train_number, t.train_name, t.source_station, t.destination_station, " +
                    "t.departure_time, t.arrival_time, t.fare, " +
                    "ts.schedule_id, ts.travel_date, ts.total_seats, " +
                    "COALESCE(SUM(b.seats_booked), 0) AS booked_seats, " +
                    "(ts.total_seats - COALESCE(SUM(b.seats_booked), 0)) AS available_seats " +
                    "FROM train_schedule ts " +
                    "JOIN trains t ON ts.train_id = t.train_id " +
                    "LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id " +
                    "GROUP BY t.train_id, t.train_number, t.train_name, t.source_station, " +
                    "t.destination_station, t.departure_time, t.arrival_time, t.fare, " +
                    "ts.schedule_id, ts.travel_date, ts.total_seats " +
                    "ORDER BY ts.travel_date, t.departure_time";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            out.println("<table>");
            out.println("<tr>");
            out.println("<th>Train No</th>");
            out.println("<th>Train Name</th>");
            out.println("<th>From</th>");
            out.println("<th>To</th>");
            out.println("<th>Departure</th>");
            out.println("<th>Arrival</th>");
            out.println("<th>Date</th>");
            out.println("<th>Fare</th>");
            out.println("<th>Available Seats</th>");
            out.println("<th>Action</th>");
            out.println("</tr>");

            while (rs.next()) {

                out.println("<tr>");
                out.println("<td>" + rs.getString("train_number") + "</td>");
                out.println("<td>" + rs.getString("train_name") + "</td>");
                out.println("<td>" + rs.getString("source_station") + "</td>");
                out.println("<td>" + rs.getString("destination_station") + "</td>");
                out.println("<td>" + rs.getString("departure_time") + "</td>");
                out.println("<td>" + rs.getString("arrival_time") + "</td>");
                out.println("<td>" + rs.getDate("travel_date") + "</td>");
                out.println("<td>Rs. " + rs.getDouble("fare") + "</td>");
                out.println("<td>" + rs.getInt("available_seats") + "</td>");

                // Book BTN
                out.println("<td>");
                out.println("<a class='book-btn' href='BookingServlet?schedule_id=" + rs.getInt("schedule_id") +
                        "&train_id=" + rs.getInt("train_id") + "'>Book</a>");
                out.println("</td>");
                out.println("</tr>");
            }

            out.println("</table>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }

        out.println("</div>");
        out.println("</body></html>");
    }
}
