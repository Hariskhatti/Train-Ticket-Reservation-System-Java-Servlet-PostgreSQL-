package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/DeleteTrainServlet")
public class DeleteTrainServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String trainNumber = request.getParameter("train_number");

        if (trainNumber == null || trainNumber.trim().isEmpty()) {
            out.println("<script>alert('Train number is required.'); window.location='delete_train.html';</script>");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false); // Start transaction

            // Step 1: Get train_id using train_number
            int trainId = -1;
            try (PreparedStatement ps = conn.prepareStatement("SELECT train_id FROM trains WHERE train_number = ?")) {
                ps.setString(1, trainNumber);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        trainId = rs.getInt("train_id");
                    }
                }
            }

            if (trainId == -1) {
                out.println("<script>alert('Train not found.'); window.location='delete_train.html';</script>");
                return;
            }

            // Step 2: Delete the train (cascades to train_schedule and bookings via FK)
            try (PreparedStatement deleteTrain = conn.prepareStatement("DELETE FROM trains WHERE train_id = ?")) {
                deleteTrain.setInt(1, trainId);
                int rowsAffected = deleteTrain.executeUpdate();

                if (rowsAffected > 0) {
                    conn.commit();
                    out.println("<script>alert('Train deleted successfully.'); window.location='ViewTrainsServlet';</script>");
                } else {
                    conn.rollback();
                    out.println("<script>alert('Failed to delete train.'); window.location='delete_train.html';</script>");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<script>alert('Error deleting train: " + e.getMessage().replace("'", "") + "'); window.location='delete_train.html';</script>");
        }
    }
}
