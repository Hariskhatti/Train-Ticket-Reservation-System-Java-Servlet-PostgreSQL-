package com.TrainReservation;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/UserDashboardServlet")
public class UserDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("userName") == null) {
            out.println("<script>alert('Session expired. Please login again.'); window.location='user_login.html';</script>");
            return;
        }

        String userName = session.getAttribute("userName").toString();

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("  <meta charset='UTF-8'>");
        out.println("  <meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("  <title>User Dashboard</title>");
        out.println("  <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'>");

        out.println("  <style>");
        out.println("    :root{ --bg1:#1d2b64; --bg2:#1e3c72; --accent:#003366; --muted:#6b7280; }");

        out.println("    body{ margin:0; font-family:'Segoe UI', system-ui, -apple-system, 'Helvetica Neue', Arial;");
        out.println("    background: linear-gradient(135deg,var(--bg1),var(--bg2)); color:white; }");

        out.println("    .header{ display:flex; justify-content:space-between; align-items:center; padding:20px 30px;");
        out.println("    backdrop-filter:blur(6px); background:rgba(255,255,255,0.05); border-bottom:1px solid rgba(255,255,255,0.1);} ");

        out.println("    .container{ max-width:1100px; margin:35px auto; }");

        out.println("    .welcome-banner{ background:rgba(255,255,255,0.95); color:#1e3c72;");
        out.println("    padding:35px; border-radius:16px; box-shadow:0 10px 30px rgba(0,0,0,0.25); text-align:center;}");

        out.println("    .welcome-banner h1{ font-size:34px; margin-bottom:10px; font-weight:800; }");
        out.println("    .welcome-banner p{ color:#4c5570; font-size:17px; margin-bottom:0; font-weight:500; }");

        out.println("    .grid{ margin-top:35px; display:grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap:22px; }");

        out.println("    .card{ background:white; color:#1e3c72; padding:22px; border-radius:14px;");
        out.println("    text-align:center; box-shadow:0 8px 28px rgba(0,0,0,0.18); transition:0.25s; }");

        out.println("    .card:hover{ transform:translateY(-6px); box-shadow:0 14px 36px rgba(0,0,0,0.25);} ");

        out.println("    .card a{ display:inline-block; margin-top:12px; padding:10px 18px;");
        out.println("    border-radius:10px; background: linear-gradient(90deg,#1e3c72,#2a5298); color:white;");
        out.println("    text-decoration:none; font-weight:700; box-shadow:0 8px 20px rgba(28,63,114,0.22);} ");

        out.println("    .promo{ margin-top:40px; text-align:center; padding:35px;");
        out.println("    background:rgba(255,255,255,0.12); border-radius:14px; border:1px solid rgba(255,255,255,0.2);} ");

        out.println("    .promo h3{ font-weight:800; margin-bottom:15px; font-size:24px; }");
        out.println("    .promo p{ margin:0; color:#d9e2ff; font-size:17px; line-height:1.5; font-weight:500; }");

        out.println("    .logout-btn{ background:linear-gradient(90deg,#c53030,#d9534f); color:white;");
        out.println("    padding:10px 16px; border-radius:10px; text-decoration:none; }");

        out.println("  </style>");
        out.println("</head>");
        out.println("<body>");

        // HEADER
        out.println("<div class='header'>");
        out.println("  <h4 class='m-0'>Railway Reservation</h4>");
        out.println("  <a href='UserLogoutServlet' class='logout-btn'><i class='fas fa-sign-out-alt me-2'></i>Logout</a>");
        out.println("</div>");

        // BODY
        out.println("<div class='container'>");

        // TOP BANNER + FUN SLOGAN
        out.println("<div class='welcome-banner'>");
        out.println("  <h1>Welcome, " + escapeHtml(userName) + "</h1>");
        out.println("  <p>Book your seat before someone else grabs it!</p>");
        out.println("</div>");

        // GRID BUTTONS
        out.println("<div class='grid'>");

        out.println("  <div class='card'>");
        out.println("    <div style='font-size:32px;'><i class='fas fa-ticket-alt'></i></div>");
        out.println("    <h5 class='mt-3'>Book Ticket</h5>");
        out.println("    <p>Reserve your seat instantly.</p>");
        out.println("    <a href='ViewUserTrainsServlet'>Book Now</a>");
        out.println("  </div>");

        out.println("  <div class='card'>");
        out.println("    <div style='font-size:32px;'><i class='fas fa-times-circle'></i></div>");
        out.println("    <h5 class='mt-3'>Cancel Ticket</h5>");
        out.println("    <p>Cancel your existing reservations.</p>");
        out.println("    <a href='CancelTicketServlet'>Cancel</a>");
        out.println("  </div>");

        out.println("  <div class='card'>");
        out.println("    <div style='font-size:32px;'><i class='fas fa-history'></i></div>");
        out.println("    <h5 class='mt-3'>Booking History</h5>");
        out.println("    <p>View all your past travels.</p>");
        out.println("    <a href='BookingHistoryServlet'>History</a>");
        out.println("  </div>");

        out.println("  <div class='card'>");
        out.println("    <div style='font-size:32px;'><i class='fas fa-user'></i></div>");
        out.println("    <h5 class='mt-3'>Profile</h5>");
        out.println("    <p>Manage your personal information.</p>");
        out.println("    <a href='UserAccountServlet'>View Profile</a>");
        out.println("  </div>");

        out.println("</div>");

        // PROMO SECTION (Fun / Friendly)
        out.println("<div class='promo'>");
        out.println("  <h3>Exclusive Travel Benefits</h3>");
        out.println("  <p>Plan ahead and enjoy smoother travel with guaranteed seats.</p>");
        out.println("  <p>Better routes, faster service, and a stress-free journey every time.</p>");
        out.println("</div>");

        out.println("</div>"); // container

        out.println("</body>");
        out.println("</html>");
    }

    private String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#x27;");
    }
}
