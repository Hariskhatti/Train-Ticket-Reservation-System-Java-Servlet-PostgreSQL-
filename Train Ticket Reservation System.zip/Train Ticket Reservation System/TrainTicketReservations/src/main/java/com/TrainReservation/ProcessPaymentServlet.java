package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.*;
import java.sql.*;

@WebServlet("/ProcessPayment")
public class ProcessPaymentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (request.getParameter("card_number") == null) {
            // First step: show payment form
            String scheduleId = request.getParameter("schedule_id");
            String seats = request.getParameter("seats_booked");
            String trainName = request.getParameter("train_name");
            String travelDate = request.getParameter("travel_date");

            out.println("<!DOCTYPE html><html><head><title>MasterCard Payment</title><style>");
            out.println("body{font-family:'Segoe UI',sans-serif;background:#e8f0fe;padding:40px;}");
            out.println(".box{background:white;padding:30px;max-width:500px;margin:auto;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.1);}");
            out.println("input{width:100%;padding:12px;margin-top:10px;border:1px solid #ccc;border-radius:6px;font-size:15px;}");
            out.println("button{margin-top:15px;padding:12px;width:100%;background:#003366;color:white;border:none;border-radius:6px;cursor:pointer;}");
            out.println("button:hover{background:#002855;}");
            out.println("</style></head><body><div class='box'>");
            out.println("<h2>MasterCard Payment</h2>");
            out.println("<form method='post' action='ProcessPayment'>");
            out.println("<input type='hidden' name='schedule_id' value='" + scheduleId + "'>");
            out.println("<input type='hidden' name='seats_booked' value='" + seats + "'>");
            out.println("<input type='hidden' name='train_name' value='" + trainName + "'>");
            out.println("<input type='hidden' name='travel_date' value='" + travelDate + "'>");
            out.println("<input type='text' name='card_name' placeholder='Cardholder Name' required>");
            out.println("<input type='text' name='card_number' placeholder='Card Number (MasterCard)' maxlength='16' required>");
            out.println("<input type='text' name='expiry' placeholder='Expiry (MM/YY)' required>");
            out.println("<input type='text' name='cvv' placeholder='CVV' maxlength='3' required>");
            out.println("<button type='submit'>Pay Now</button>");
            out.println("</form></div></body></html>");
            return;
        }

        try {
            int scheduleId = Integer.parseInt(request.getParameter("schedule_id"));
            int seatsBooked = Integer.parseInt(request.getParameter("seats_booked"));

            String cardNumber = request.getParameter("card_number");
            String cardName = request.getParameter("card_name");
            String expiry = request.getParameter("expiry");
            String cvv = request.getParameter("cvv");

            if (cardNumber.length() != 16 || !cardNumber.startsWith("1")) {
                out.println("<script>alert('Invalid MasterCard number'); history.back();</script>");
                return;
            }

            Connection conn = DBConnection.getConnection();

            // Step 1: Get train_id and total_seats from schedule
            String scheduleQuery = "SELECT train_id, total_seats FROM train_schedule WHERE schedule_id = ?";
            PreparedStatement ps1 = conn.prepareStatement(scheduleQuery);
            ps1.setInt(1, scheduleId);
            ResultSet rs1 = ps1.executeQuery();

            if (!rs1.next()) {
                out.println("<h3 style='color:red;'>Invalid schedule ID.</h3>");
                return;
            }

            int trainId = rs1.getInt("train_id");
            int totalSeats = rs1.getInt("total_seats");
            rs1.close();
            ps1.close();

            // Step 2: Get fare from trains table using train_id
            String fareQuery = "SELECT fare FROM trains WHERE train_id = ?";
            PreparedStatement ps2 = conn.prepareStatement(fareQuery);
            ps2.setInt(1, trainId);
            ResultSet rs2 = ps2.executeQuery();

            if (!rs2.next()) {
                out.println("<h3 style='color:red;'>Train fare not found.</h3>");
                return;
            }

            double farePerSeat = rs2.getDouble("fare");
            rs2.close();
            ps2.close();

            // Step 3: Get already booked seats
            String bookedQuery = "SELECT COALESCE(SUM(seats_booked), 0) AS booked FROM bookings WHERE schedule_id = ?";
            PreparedStatement ps3 = conn.prepareStatement(bookedQuery);
            ps3.setInt(1, scheduleId);
            ResultSet rs3 = ps3.executeQuery();
            rs3.next();
            int bookedSeats = rs3.getInt("booked");
            rs3.close();
            ps3.close();

            int availableSeats = totalSeats - bookedSeats;

            if (availableSeats < seatsBooked) {
                out.println("<script>alert('Only " + availableSeats + " seats are available.'); window.location='UserDashboardServlet';</script>");
                return;
            }

            double totalAmount = farePerSeat * seatsBooked;

            // Step 4: Insert booking
            String insertQuery = "INSERT INTO bookings (user_id, schedule_id, seats_booked, total_amount, payment_status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertPs = conn.prepareStatement(insertQuery);
            insertPs.setInt(1, userId);
            insertPs.setInt(2, scheduleId);
            insertPs.setInt(3, seatsBooked);
            insertPs.setDouble(4, totalAmount);
            insertPs.setString(5, "PAID");
            insertPs.executeUpdate();
            insertPs.close();

            conn.close();

            // Step 5: Confirmation page
            out.println("<!DOCTYPE html><html><head><title>Payment Success</title><style>");
            out.println("body{font-family:'Segoe UI',sans-serif;background-color:#e8f0fe;padding:40px;}");
            out.println(".box{background:white;padding:30px;max-width:500px;margin:auto;border-radius:12px;box-shadow:0 4px 12px rgba(0,0,0,0.1);text-align:center;}");
            out.println("h2{color:green;margin-bottom:20px;}");
            out.println("a{display:inline-block;margin-top:20px;padding:10px 20px;background:#003366;color:white;border-radius:6px;text-decoration:none;}");
            out.println("a:hover{background:#002855;}");
            out.println("</style></head><body>");
            out.println("<div class='box'>");
            out.println("<h2>Ticket Booked Successfully!</h2>");
            out.println("<p>Your payment of <strong>Rs. " + totalAmount + "</strong> for <strong>" + seatsBooked + "</strong> seat(s) has been received.</p>");
            out.println("<a href='UserDashboardServlet'>Back to Dashboard</a>");
            out.println("</div></body></html>");

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
        }
    }
}
