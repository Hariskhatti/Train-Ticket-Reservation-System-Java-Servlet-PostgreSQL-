package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/DetailedTrainViewServlet")
public class DetailedTrainViewServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String trainId = request.getParameter("train_id");
        if (trainId == null) {
            out.println("<script>alert('Invalid train ID.'); history.back();</script>");
            return;
        }

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Train Details - Train Reservation System</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'>");
        out.println("<style>");
        out.println("body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; font-family: 'Segoe UI', sans-serif; }");
        out.println(".details-container { max-width: 1000px; margin: 50px auto; padding: 0 20px; }");
        out.println(".details-card { background: rgba(255, 255, 255, 0.95); border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); animation: fadeInUp 0.8s ease-out; }");
        out.println("@keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }");
        out.println(".train-header { text-align: center; margin-bottom: 40px; }");
        out.println(".train-icon { font-size: 4rem; color: #003366; margin-bottom: 20px; }");
        out.println(".train-title { color: #003366; font-size: 2.5rem; font-weight: 700; margin-bottom: 10px; }");
        out.println(".train-subtitle { color: #666; font-size: 1.2rem; }");
        out.println(".info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 40px; }");
        out.println(".info-card { background: #f8f9fa; border-radius: 15px; padding: 25px; text-align: center; transition: transform 0.3s ease; }");
        out.println(".info-card:hover { transform: translateY(-5px); }");
        out.println(".info-icon { font-size: 2.5rem; margin-bottom: 15px; }");
        out.println(".info-label { font-weight: 600; color: #003366; margin-bottom: 5px; }");
        out.println(".info-value { color: #666; font-size: 1.1rem; }");
        out.println(".schedule-section { margin-top: 40px; }");
        out.println(".schedule-title { color: #003366; font-size: 1.8rem; font-weight: 600; margin-bottom: 20px; text-align: center; }");
        out.println(".table { background: white; border-radius: 10px; overflow: hidden; }");
        out.println(".table th { background: #003366; color: white; }");
        out.println(".btn-custom { background: linear-gradient(45deg, #003366, #002855); border: none; border-radius: 25px; padding: 12px 30px; color: white; text-decoration: none; font-weight: 500; transition: all 0.3s ease; }");
        out.println(".btn-custom:hover { transform: translateY(-3px); box-shadow: 0 8px 15px rgba(0,0,0,0.2); color: white; }");
        out.println(".actions { text-align: center; margin-top: 40px; }");
        out.println("@media (max-width: 768px) { .info-grid { grid-template-columns: 1fr; } .train-title { font-size: 2rem; } }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<div class='container details-container'>");
        out.println("<div class='details-card'>");

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT * FROM trains WHERE train_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(trainId));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                out.println("<div class='train-header'>");
                out.println("<div class='train-icon'><i class='fas fa-train'></i></div>");
                out.println("<h1 class='train-title'>" + rs.getString("train_name") + "</h1>");
                out.println("<p class='train-subtitle'>Train Number: " + rs.getString("train_number") + "</p>");
                out.println("</div>");

                out.println("<div class='info-grid'>");
                out.println("<div class='info-card'>");
                out.println("<div class='info-icon' style='color: #28a745;'><i class='fas fa-map-marker-alt'></i></div>");
                out.println("<div class='info-label'>From</div>");
                out.println("<div class='info-value'>" + rs.getString("source_station") + "</div>");
                out.println("</div>");

                out.println("<div class='info-card'>");
                out.println("<div class='info-icon' style='color: #dc3545;'><i class='fas fa-map-marker-alt'></i></div>");
                out.println("<div class='info-label'>To</div>");
                out.println("<div class='info-value'>" + rs.getString("destination_station") + "</div>");
                out.println("</div>");

                out.println("<div class='info-card'>");
                out.println("<div class='info-icon' style='color: #ffc107;'><i class='fas fa-clock'></i></div>");
                out.println("<div class='info-label'>Departure</div>");
                out.println("<div class='info-value'>" + rs.getString("departure_time") + "</div>");
                out.println("</div>");

                out.println("<div class='info-card'>");
                out.println("<div class='info-icon' style='color: #17a2b8;'><i class='fas fa-clock'></i></div>");
                out.println("<div class='info-label'>Arrival</div>");
                out.println("<div class='info-value'>" + rs.getString("arrival_time") + "</div>");
                out.println("</div>");

                out.println("<div class='info-card'>");
                out.println("<div class='info-icon' style='color: #6f42c1;'><i class='fas fa-chair'></i></div>");
                out.println("<div class='info-label'>Total Seats</div>");
                out.println("<div class='info-value'>" + rs.getInt("total_seats") + "</div>");
                out.println("</div>");

                out.println("<div class='info-card'>");
                out.println("<div class='info-icon' style='color: #fd7e14;'><i class='fas fa-dollar-sign'></i></div>");
                out.println("<div class='info-label'>Fare per Seat</div>");
                out.println("<div class='info-value'>Rs. " + rs.getInt("fare") + "</div>");
                out.println("</div>");
                out.println("</div>");

                // Schedule Section
                out.println("<div class='schedule-section'>");
                out.println("<h2 class='schedule-title'><i class='fas fa-calendar-alt me-2'></i>Available Schedules</h2>");
                String scheduleSql = "SELECT travel_date, available_seats FROM train_schedule WHERE train_id = ? ORDER BY travel_date";
                PreparedStatement ps2 = conn.prepareStatement(scheduleSql);
                ps2.setInt(1, Integer.parseInt(trainId));
                ResultSet rs2 = ps2.executeQuery();

                out.println("<table class='table table-striped'>");
                out.println("<thead><tr><th>Date</th><th>Available Seats</th><th>Action</th></tr></thead><tbody>");
                while (rs2.next()) {
                    out.println("<tr>");
                    out.println("<td>" + rs2.getDate("travel_date") + "</td>");
                    out.println("<td>" + rs2.getInt("available_seats") + "</td>");
                    out.println("<td><a href='BookTicketServlet?train_name=" + rs.getString("train_name") + "&source_station=" + rs.getString("source_station") + "&destination_station=" + rs.getString("destination_station") + "&travel_date=" + rs2.getDate("travel_date") + "' class='btn btn-sm btn-primary'>Book Now</a></td>");
                    out.println("</tr>");
                }
                out.println("</tbody></table>");

                rs2.close();
                ps2.close();
            } else {
                out.println("<p class='text-danger text-center'>Train not found.</p>");
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p class='text-danger text-center'>Error loading train details: " + e.getMessage() + "</p>");
        }

        out.println("<div class='actions'>");
        out.println("<a href='ViewUserTrainsServlet' class='btn btn-secondary btn-custom me-3'><i class='fas fa-arrow-left me-2'></i>Back to Trains</a>");
        out.println("<a href='UserDashboardServlet' class='btn btn-primary btn-custom'><i class='fas fa-home me-2'></i>Dashboard</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>");
        out.println("</body></html>");
    }
}
