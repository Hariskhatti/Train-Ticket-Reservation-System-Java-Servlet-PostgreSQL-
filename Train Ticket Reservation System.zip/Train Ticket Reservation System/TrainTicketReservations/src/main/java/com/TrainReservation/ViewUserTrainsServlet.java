package com.TrainReservation;

import com.util.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/ViewUserTrainsServlet")
public class ViewUserTrainsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();

            String sql =
                "SELECT t.train_id, t.train_number, t.train_name, t.source_station, t.destination_station, " +
                "t.departure_time, t.arrival_time, t.fare, " +
                "ts.schedule_id, ts.travel_date, ts.total_seats, " +
                "(ts.total_seats - COALESCE(SUM(b.seats_booked),0)) AS remaining_seats " +
                "FROM trains t " +
                "LEFT JOIN train_schedule ts ON t.train_id = ts.train_id " +
                "LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id " +
                "GROUP BY t.train_id, t.train_number, t.train_name, t.source_station, t.destination_station, " +
                "t.departure_time, t.arrival_time, t.fare, ts.schedule_id, ts.travel_date, ts.total_seats " +
                "ORDER BY t.train_number";

            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            out.println("<html><head><title>Available Trains</title>");
            out.println("<style>");
            out.println("body{font-family: 'Segoe UI'; background:#e8f0ff; padding:30px;}");
            out.println(".box{max-width:1200px; margin:auto; background:white; padding:30px;"
                    + "border-radius:12px; box-shadow:0 8px 18px rgba(0,0,0,0.12);} ");
            out.println("table{width:100%; border-collapse:collapse;}");
            out.println("th,td{padding:12px; text-align:center; border-bottom:1px solid #ddd;}");
            out.println("th{background:#003366; color:white;}");
            out.println(".btn{padding:8px 14px; background:#003366; color:white;"
                    + "text-decoration:none; border-radius:6px; font-size:14px;}");
            out.println("</style></head><body>");
            out.println("<div class='box'>");

            out.println("<h2>Available Trains</h2>");

            out.println("<table>");
            out.println("<tr>"
                    + "<th>Train No</th>"
                    + "<th>Name</th>"
                    + "<th>From</th>"
                    + "<th>To</th>"
                    + "<th>Departure</th>"
                    + "<th>Arrival</th>"
                    + "<th>Date</th>"
                    + "<th>Remaining Seats</th>"
                    + "<th>Fare</th>"
                    + "<th>Action</th>"
                    + "</tr>");

            while (rs.next()) {

                if (rs.getDate("travel_date") == null) continue;

                out.println("<tr>");
                out.println("<td>" + rs.getString("train_number") + "</td>");
                out.println("<td>" + rs.getString("train_name") + "</td>");
                out.println("<td>" + rs.getString("source_station") + "</td>");
                out.println("<td>" + rs.getString("destination_station") + "</td>");
                out.println("<td>" + rs.getString("departure_time") + "</td>");
                out.println("<td>" + rs.getString("arrival_time") + "</td>");
                out.println("<td>" + rs.getString("travel_date") + "</td>");
                out.println("<td>" + rs.getInt("remaining_seats") + "</td>");
                out.println("<td>" + rs.getInt("fare") + "</td>");

                // BOOK BUTTON → pass all values
                out.println("<td>"
                        + "<a class='btn' href='BookTicketServlet?"
                        + "train_name=" + rs.getString("train_name")
                        + "&source_station=" + rs.getString("source_station")
                        + "&destination_station=" + rs.getString("destination_station")
                        + "&travel_date=" + rs.getString("travel_date")
                        + "&fare=" + rs.getInt("fare")
                        + "&schedule_id=" + rs.getInt("schedule_id")
                        + "'>Book</a></td>");

                out.println("</tr>");
            }

            out.println("</table>");
            out.println("<br><a class='btn' href='UserDashboardServlet'>Back</a>");
            out.println("</div></body></html>");

        } catch (Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }
    }
}
