package com.TrainReservation;

import com.util.DBConnection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/AddScheduleServlet")
public class AddScheduleServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String trainNumber = request.getParameter("train_number").trim();
        String travelDate = request.getParameter("travel_date").trim();
        String seatsStr = request.getParameter("available_seats").trim();

        int totalSeats;
        try {
            totalSeats = Integer.parseInt(seatsStr);
        } catch (NumberFormatException e) {
            showMessage(out, "Invalid number of seats.", false);
            return;
        }

        try {
            Connection conn = DBConnection.getConnection();

            // Get train_id using train_number
            String trainQuery = "SELECT train_id FROM trains WHERE train_number = ?";
            PreparedStatement trainPs = conn.prepareStatement(trainQuery);
            trainPs.setString(1, trainNumber);
            ResultSet trainRs = trainPs.executeQuery();

            if (!trainRs.next()) {
                showMessage(out, "Train number not found!", false);
                trainPs.close();
                trainRs.close();
                conn.close();
                return;
            }

            int trainId = trainRs.getInt("train_id");
            trainPs.close();
            trainRs.close();

            // Check if schedule already exists
            String checkQuery = "SELECT * FROM train_schedule WHERE train_id = ? AND travel_date = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkQuery);
            checkPs.setInt(1, trainId);
            checkPs.setDate(2, Date.valueOf(travelDate));
            ResultSet checkRs = checkPs.executeQuery();

            if (checkRs.next()) {
                showMessage(out, "Schedule already exists for this train on " + travelDate, false);
                checkPs.close();
                checkRs.close();
                conn.close();
                return;
            }

            checkPs.close();
            checkRs.close();

            // Insert schedule
            String insertQuery = "INSERT INTO train_schedule (train_id, travel_date, total_seats) VALUES (?, ?, ?)";
            PreparedStatement insertPs = conn.prepareStatement(insertQuery);
            insertPs.setInt(1, trainId);
            insertPs.setDate(2, Date.valueOf(travelDate));
            insertPs.setInt(3, totalSeats);

            int result = insertPs.executeUpdate();
            insertPs.close();
            conn.close();

            if (result > 0) {
                showMessage(out, "Schedule added successfully!", true);
            } else {
                showMessage(out, "Failed to add schedule.", false);
            }

        } catch (Exception e) {
            e.printStackTrace();
            showMessage(out, "Error: " + e.getMessage(), false);
        }
    }

    private void showMessage(PrintWriter out, String message, boolean success) {
        out.println("<!DOCTYPE html><html><head><title>Schedule Result</title>");
        out.println("<script>");
        out.println("alert('" + message.replace("'", "\\'") + "');");
        out.println("window.location.href = 'add_schedule.html';");
        out.println("</script>");
        out.println("</head><body></body></html>");
    }
}
