package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/BookingConfirmationServlet")
public class BookingConfirmationServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            response.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        String bookingId = request.getParameter("booking_id");

        if (bookingId == null) {
            out.println("<script>alert('Invalid booking.'); window.location='UserDashboardServlet';</script>");
            return;
        }

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Booking Confirmation - Train Reservation System</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'>");
        out.println("<style>");
        out.println("body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; font-family: 'Segoe UI', sans-serif; }");
        out.println(".confirmation-container { max-width: 800px; margin: 50px auto; padding: 0 20px; }");
        out.println(".confirmation-card { background: rgba(255, 255, 255, 0.95); border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); text-align: center; animation: fadeInUp 0.8s ease-out; }");
        out.println("@keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }");
        out.println(".success-icon { font-size: 4rem; color: #28a745; margin-bottom: 20px; animation: bounceIn 1s ease-out; }");
        out.println("@keyframes bounceIn { 0% { transform: scale(0); } 50% { transform: scale(1.2); } 100% { transform: scale(1); } }");
        out.println(".confirmation-title { color: #003366; font-size: 2.5rem; font-weight: 700; margin-bottom: 10px; }");
        out.println(".confirmation-subtitle { color: #666; font-size: 1.2rem; margin-bottom: 30px; }");
        out.println(".booking-details { background: #f8f9fa; border-radius: 15px; padding: 25px; margin: 30px 0; text-align: left; }");
        out.println(".detail-row { display: flex; justify-content: space-between; margin-bottom: 10px; }");
        out.println(".detail-label { font-weight: 600; color: #003366; }");
        out.println(".detail-value { color: #666; }");
        out.println(".btn-custom { background: linear-gradient(45deg, #003366, #002855); border: none; border-radius: 25px; padding: 12px 30px; color: white; text-decoration: none; font-weight: 500; transition: all 0.3s ease; }");
        out.println(".btn-custom:hover { transform: translateY(-3px); box-shadow: 0 8px 15px rgba(0,0,0,0.2); color: white; }");
        out.println(".actions { margin-top: 40px; }");
        out.println("@media (max-width: 768px) { .confirmation-title { font-size: 2rem; } .detail-row { flex-direction: column; } }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<div class='container confirmation-container'>");
        out.println("<div class='confirmation-card'>");
        out.println("<div class='success-icon'><i class='fas fa-check-circle'></i></div>");
        out.println("<h1 class='confirmation-title'>Booking Confirmed!</h1>");
        out.println("<p class='confirmation-subtitle'>Your train ticket has been successfully booked. Details are below.</p>");

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT b.booking_id, b.seats_booked, b.total_amount, b.booking_time, " +
                         "t.train_name, t.source_station, t.destination_station, t.departure_time, t.arrival_time, " +
                         "ts.travel_date " +
                         "FROM bookings b " +
                         "JOIN train_schedule ts ON b.schedule_id = ts.schedule_id " +
                         "JOIN trains t ON ts.train_id = t.train_id " +
                         "WHERE b.booking_id = ? AND b.user_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(bookingId));
            ps.setInt(2, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                out.println("<div class='booking-details'>");
                out.println("<div class='detail-row'><span class='detail-label'>Booking ID:</span><span class='detail-value'>" + rs.getInt("booking_id") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>Train:</span><span class='detail-value'>" + rs.getString("train_name") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>From:</span><span class='detail-value'>" + rs.getString("source_station") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>To:</span><span class='detail-value'>" + rs.getString("destination_station") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>Date:</span><span class='detail-value'>" + rs.getDate("travel_date") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>Departure:</span><span class='detail-value'>" + rs.getString("departure_time") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>Arrival:</span><span class='detail-value'>" + rs.getString("arrival_time") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>Seats:</span><span class='detail-value'>" + rs.getInt("seats_booked") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>Total Amount:</span><span class='detail-value'>Rs. " + rs.getDouble("total_amount") + "</span></div>");
                out.println("<div class='detail-row'><span class='detail-label'>Booking Time:</span><span class='detail-value'>" + rs.getTimestamp("booking_time") + "</span></div>");
                out.println("</div>");
            } else {
                out.println("<p class='text-danger'>Booking details not found.</p>");
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p class='text-danger'>Error loading booking details: " + e.getMessage() + "</p>");
        }

        out.println("<div class='actions'>");
        out.println("<a href='UserDashboardServlet' class='btn btn-primary btn-custom me-3'><i class='fas fa-home me-2'></i>Back to Dashboard</a>");
        out.println("<a href='BookingHistoryServlet' class='btn btn-secondary btn-custom'><i class='fas fa-history me-2'></i>View Booking History</a>");
        out.println("</div>");
        out.println("</div>");
        out.println("</div>");

        out.println("<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js'></script>");
        out.println("</body></html>");
    }
}
