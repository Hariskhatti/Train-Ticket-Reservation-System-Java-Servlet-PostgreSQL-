package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/DeleteScheduleServlet")
public class DeleteScheduleServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        int scheduleId = Integer.parseInt(request.getParameter("schedule_id"));
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("DELETE FROM train_schedule WHERE schedule_id = ?");
            ps.setInt(1, scheduleId);
            int rows = ps.executeUpdate();

            ps.close();
            conn.close();

            response.sendRedirect("ViewScheduleServlet");

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p style='color:red;'>Failed to delete schedule: " + e.getMessage() + "</p>");
        }
    }
}
