package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/SeeReservationServlet")
public class SeeReservationServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin_login.html");
            return;
        }

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>See Reservations</title>");
        out.println("<meta charset='UTF-8'>");
        out.println("<style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 50px; }");
        out.println(".container { background: white; padding: 30px; max-width: 800px; margin: auto; border-radius: 12px; box-shadow: 0 3px 12px rgba(0,0,0,0.1); }");
        out.println("h2 { color: #003366; text-align: center; }");
        out.println("form { margin-top: 20px; text-align: center; }");
        out.println("input, select { padding: 10px; margin: 10px; width: 40%; border-radius: 6px; border: 1px solid #ccc; font-size: 14px; }");
        out.println("input[type='submit'] { background-color: #003366; color: white; cursor: pointer; }");
        out.println("input[type='submit']:hover { background-color: #002855; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-top: 30px; }");
        out.println("th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }");
        out.println("th { background-color: #003366; color: white; }");
        out.println(".btn { margin-top: 30px; display: block; background: #003366; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; text-align: center; }");
        out.println(".btn:hover { background: #002855; }");
        out.println("</style>");
        out.println("</head><body>");

        out.println("<div class='container'>");
        out.println("<h2>See Train Reservations</h2>");
        out.println("<form method='post'>");
        out.println("<input type='text' name='train_name' placeholder='Enter Train Name' required>");
        out.println("<input type='date' name='travel_date' required>");
        out.println("<input type='submit' value='Fetch Bookings'>");
        out.println("</form>");

        out.println("</div></body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String trainName = request.getParameter("train_name");
        String travelDate = request.getParameter("travel_date");

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Reservations</title>");
        out.println("<meta charset='UTF-8'>");
        out.println("<style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 50px; }");
        out.println(".container { background: white; padding: 30px; max-width: 900px; margin: auto; border-radius: 12px; box-shadow: 0 3px 12px rgba(0,0,0,0.1); }");
        out.println("h2 { color: #003366; text-align: center; margin-bottom: 20px; }");
        out.println("table { width: 100%; border-collapse: collapse; }");
        out.println("th, td { border: 1px solid #ccc; padding: 10px; text-align: left; }");
        out.println("th { background-color: #003366; color: white; }");
        out.println(".btn { margin-top: 30px; display: block; background: #003366; color: white; padding: 10px 20px; text-decoration: none; border-radius: 6px; text-align: center; }");
        out.println(".btn:hover { background: #002855; }");
        out.println("</style>");
        out.println("</head><body>");

        out.println("<div class='container'>");
        out.println("<h2>Bookings for '" + trainName + "' on " + travelDate + "</h2>");

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT u.full_name, u.email, b.seats_booked, b.booking_time, t.train_name, ts.travel_date " +
                         "FROM bookings b " +
                         "JOIN users u ON b.user_id = u.user_id " +
                         "JOIN train_schedule ts ON b.schedule_id = ts.schedule_id " +
                         "JOIN trains t ON ts.train_id = t.train_id " +
                         "WHERE t.train_name = ? AND ts.travel_date = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, trainName);
            ps.setDate(2, Date.valueOf(travelDate));
            ResultSet rs = ps.executeQuery();

            boolean found = false;
            out.println("<table>");
            out.println("<tr><th>Username</th><th>Email</th><th>Seats Booked</th><th>Booking Time</th></tr>");
            while (rs.next()) {
                found = true;
                out.println("<tr>");
                out.println("<td>" + rs.getString("full_name") + "</td>");
                out.println("<td>" + rs.getString("email") + "</td>");
                out.println("<td>" + rs.getInt("seats_booked") + "</td>");
                out.println("<td>" + rs.getTimestamp("booking_time") + "</td>");
                out.println("</tr>");
            }
            out.println("</table>");

            if (!found) {
                out.println("<p style='color: red; text-align: center; margin-top: 20px;'>No bookings found for this train and date.</p>");
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            out.println("<p style='color:red; text-align: center;'>Error: " + e.getMessage() + "</p>");
        }

        out.println("<a href='AdminDashboardServlet' class='btn'>Back to Dashboard</a>");
        out.println("</div></body></html>");
    }
}
