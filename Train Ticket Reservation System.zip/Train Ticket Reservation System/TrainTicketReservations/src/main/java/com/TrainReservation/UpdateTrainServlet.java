package com.TrainReservation;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import com.util.DBConnection;

@WebServlet("/UpdateTrainServlet")
public class UpdateTrainServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        showForm(response, false, "");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin_login.html");
            return;
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String trainNumber = request.getParameter("train_number");
        String trainName = request.getParameter("train_name");
        String source = request.getParameter("source");
        String destination = request.getParameter("destination");
        String departureTime = request.getParameter("departure_time");
        String arrivalTime = request.getParameter("arrival_time");
        int totalSeats = Integer.parseInt(request.getParameter("total_seats"));
        double fare = Double.parseDouble(request.getParameter("fare"));

        String message = "";
        boolean isSuccess = false;

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE trains SET train_name=?, source_station=?, destination_station=?, departure_time=?, arrival_time=?, total_seats=?, fare=? WHERE train_number=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, trainName);
            ps.setString(2, source);
            ps.setString(3, destination);
            ps.setTime(4, Time.valueOf(departureTime.length() == 5 ? departureTime + ":00" : departureTime));
            ps.setTime(5, Time.valueOf(arrivalTime.length() == 5 ? arrivalTime + ":00" : arrivalTime));
            ps.setInt(6, totalSeats);
            ps.setDouble(7, fare);
            ps.setString(8, trainNumber);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                isSuccess = true;
                message = "Train details updated successfully!";
            } else {
                message = "No train found with the given train number.";
            }

        } catch (Exception e) {
            message = "Error: " + e.getMessage();
        }

        showForm(response, isSuccess, message);
    }

    private void showForm(HttpServletResponse response, boolean isSuccess, String message) throws IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html");

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Update Train</title>");
        out.println("<meta charset='UTF-8'>");
        out.println("<style>");
        out.println("body { background-color: #e8f0fe; font-family: 'Segoe UI', sans-serif; padding: 40px; }");
        out.println(".form-box { background: white; padding: 30px; max-width: 500px; margin: auto; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }");
        out.println("h2 { text-align: center; color: #003366; margin-bottom: 25px; }");
        out.println("input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ccc; border-radius: 6px; }");
        out.println("button { width: 100%; padding: 12px; background-color: #003366; color: white; font-size: 16px; border: none; border-radius: 6px; }");
        out.println("button:hover { background-color: #002855; }");
        out.println(".message { text-align: center; margin-bottom: 15px; color: " + (isSuccess ? "green" : "red") + "; }");
        out.println("</style></head><body>");

        out.println("<div class='form-box'>");
        out.println("<h2>Update Train Details</h2>");

        if (!message.isEmpty()) {
            out.println("<div class='message'>" + message + "</div>");
        }

        out.println("<form method='post' action='UpdateTrainServlet'>");
        out.println("<input type='text' name='train_number' placeholder='Train Number' required>");
        out.println("<input type='text' name='train_name' placeholder='Train Name' required>");
        out.println("<input type='text' name='source' placeholder='Source Station' required>");
        out.println("<input type='text' name='destination' placeholder='Destination Station' required>");
        out.println("<input type='time' name='departure_time' placeholder='HH:MM' required>");
        out.println("<input type='time' name='arrival_time' placeholder='HH:MM' required>");
        out.println("<input type='number' name='total_seats' placeholder='Total Seats' required>");
        out.println("<input type='number' step='0.01' name='fare' placeholder='Fare' required>");
        out.println("<button type='submit'>Update Train</button>");
        out.println("</form>");

        out.println("<br><a href='AdminDashboardServlet'><button>Back to Dashboard</button></a>");
        out.println("</div></body></html>");
    }
}
