package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/UserManagementServlet")
public class UserManagementServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin_login.html");
            return;
        }

        // -------------------------------
        // ✔ DELETE USER (Same File Me)
        // -------------------------------
        String action = request.getParameter("action");
        String userIdToDelete = request.getParameter("user_id");

        if ("delete".equals(action) && userIdToDelete != null) {
            try {
                Connection conn = DBConnection.getConnection();
                String deleteSQL = "DELETE FROM users WHERE user_id = ?";
                PreparedStatement deletePs = conn.prepareStatement(deleteSQL);
                deletePs.setInt(1, Integer.parseInt(userIdToDelete));
                deletePs.executeUpdate();
                deletePs.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
                out.println("<script>alert('Error deleting user');</script>");
            }

            response.sendRedirect("UserManagementServlet");
            return;
        }

        // -------------------------------
        // HTML DESIGN START
        // -------------------------------
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>User Management - Train Reservation System</title>");

        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'>");

        out.println("<style>");
        out.println("body { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); min-height: 100vh; font-family: 'Segoe UI', sans-serif; }");
        out.println(".management-container { max-width: 1200px; margin: 50px auto; padding: 0 20px; }");
        out.println(".management-card { background: rgba(255, 255, 255, 0.95); border-radius: 20px; padding: 40px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); animation: fadeInUp 0.8s ease-out; }");

        out.println("@keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }");

        out.println(".header { text-align: center; margin-bottom: 40px; }");
        out.println(".header-icon { font-size: 4rem; color: #003366; margin-bottom: 20px; }");
        out.println(".header-title { color: #003366; font-size: 2.5rem; font-weight: 700; margin-bottom: 10px; }");
        out.println(".header-subtitle { color: #666; font-size: 1.2rem; }");

        out.println(".table { background: white; border-radius: 10px; overflow: hidden; }");
        out.println(".table th { background: #003366; color: white; }");

        out.println(".btn-danger-custom { background: linear-gradient(45deg, #dc3545, #c82333); color:white; }");
        out.println(".btn-danger-custom:hover { background: linear-gradient(45deg, #c82333, #a02622); }");

        out.println(".btn-custom { background: linear-gradient(45deg, #003366, #002855); color:white; }");

        out.println("</style>");
        out.println("</head>");
        out.println("<body>");

        out.println("<div class='container management-container'>");
        out.println("<div class='management-card'>");

        out.println("<div class='header'>");
        out.println("<div class='header-icon'><i class='fas fa-users-cog'></i></div>");
        out.println("<h1 class='header-title'>User Management</h1>");
        out.println("<p class='header-subtitle'>Manage registered users and their accounts</p>");
        out.println("</div>");

        try {

            Connection conn = DBConnection.getConnection();

            // -------------------------
            // Total Users Count
            // -------------------------
            String countSql = "SELECT COUNT(*) AS total_users FROM users";
            PreparedStatement psCount = conn.prepareStatement(countSql);
            ResultSet rsCount = psCount.executeQuery();
            rsCount.next();
            int totalUsers = rsCount.getInt("total_users");
            rsCount.close();
            psCount.close();

            // Stats Section
            out.println("<div class='stats-grid'>");
            out.println("<div class='stat-card'>");
            out.println("<div class='stat-number'>" + totalUsers + "</div>");
            out.println("<div class='stat-label'>Total Users</div>");
            out.println("</div>");
            out.println("</div>");

            // -------------------------
            // Users Table
            // -------------------------
            String sql = "SELECT user_id, full_name, email, phone, created_at FROM users ORDER BY created_at DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            out.println("<table class='table table-striped'>");
            out.println("<thead><tr>");
            out.println("<th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Registered</th><th>Actions</th>");
            out.println("</tr></thead><tbody>");

            while (rs.next()) {
                int uid = rs.getInt("user_id");

                out.println("<tr>");
                out.println("<td>" + uid + "</td>");
                out.println("<td>" + rs.getString("full_name") + "</td>");
                out.println("<td>" + rs.getString("email") + "</td>");
                out.println("<td>" + rs.getString("phone") + "</td>");
                out.println("<td>" + rs.getTimestamp("created_at") + "</td>");

                // Actions Column
                out.println("<td>");
                out.println("<a href='UserManagementServlet?action=delete&user_id=" + uid +
                        "' class='btn btn-sm btn-danger-custom' onclick='return confirm(\"Delete this user?\")'>");
                out.println("<i class='fas fa-trash'></i> Delete</a>");
                out.println("</td>");

                out.println("</tr>");
            }

            out.println("</tbody></table>");

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p class='text-danger text-center'>Error loading users: " + e.getMessage() + "</p>");
        }

        out.println("<div class='actions text-center mt-4'>");
        out.println("<a href='AdminDashboardServlet' class='btn btn-custom'><i class='fas fa-arrow-left me-2'></i>Back to Dashboard</a>");
        out.println("</div>");

        out.println("</div>");
        out.println("</div>");

        out.println("</body></html>");
    }
}
