package com.TrainReservation;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/AdminDashboardServlet")
public class AdminDashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminName") == null) {
            response.sendRedirect("admin_login.html");
            return;
        }

        String adminName = (String) session.getAttribute("adminName");

        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Admin Dashboard</title>");
        out.println("<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>");
        out.println("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css'>");

        out.println("<style>");

        /* Main background */
        out.println("body {");
        out.println("  margin:0;");
        out.println("  font-family: 'Segoe UI', sans-serif;");
        out.println("  background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);");
        out.println("  color:white;");
        out.println("}");

        /* Header Banner */
        out.println(".header-banner {");
        out.println("  background: linear-gradient(135deg, #0a3d62, #1e6091, #144f7a);");
        out.println("  padding: 55px 20px;");
        out.println("  text-align: center;");
        out.println("  border-bottom-left-radius: 40px;");
        out.println("  border-bottom-right-radius: 40px;");
        out.println("  box-shadow: 0 10px 25px rgba(0,0,0,0.4);");
        out.println("}");

        out.println(".header-title { font-size: 42px; font-weight: 800; }");
        out.println(".welcome-text { margin-top: 10px; font-size: 17px; opacity: 0.9; }");

        /* Buttons row */
        out.println(".button-row { display: flex; justify-content: center; gap: 25px; margin-top: 45px; flex-wrap: wrap; }");

        /* Buttons */
        out.println(".dash-btn {");
        out.println("  padding: 16px 28px;");
        out.println("  border-radius: 16px;");
        out.println("  font-size: 16px;");
        out.println("  font-weight: 700;");
        out.println("  backdrop-filter: blur(10px);");
        out.println("  background: rgba(255,255,255,0.12);");
        out.println("  border: 1px solid rgba(255,255,255,0.25);");
        out.println("  color: white;");
        out.println("  text-decoration: none;");
        out.println("  box-shadow: 0 8px 20px rgba(0,0,0,0.4);");
        out.println("  transition: 0.25s;");
        out.println("}");

        out.println(".dash-btn:hover {");
        out.println("  transform: translateY(-7px) scale(1.05);");
        out.println("  background: rgba(255,255,255,0.22);");
        out.println("  box-shadow: 0 14px 28px rgba(0,0,0,0.55);");
        out.println("}");

        /* Bottom Stats Section */
        out.println(".stats-container {");
        out.println("  max-width: 1100px;");
        out.println("  margin: 80px auto;");
        out.println("  padding: 40px;");
        out.println("  background: rgba(255,255,255,0.10);");
        out.println("  border-radius: 25px;");
        out.println("  box-shadow: 0 20px 40px rgba(0,0,0,0.40);");
        out.println("  backdrop-filter: blur(12px);");
        out.println("}");

        out.println(".stats-title { font-size: 26px; font-weight: 700; margin-bottom: 25px; text-align:center; }");

        out.println(".stats-grid { display: grid; grid-template-columns: repeat(auto-fit,minmax(220px,1fr)); gap: 25px; }");

        out.println(".stat-box {");
        out.println("  background: rgba(255,255,255,0.15);");
        out.println("  padding: 25px;");
        out.println("  border-radius: 18px;");
        out.println("  text-align: center;");
        out.println("  box-shadow: 0 10px 25px rgba(0,0,0,0.35);");
        out.println("  transition: 0.3s;");
        out.println("}");
        out.println(".stat-box:hover { transform: translateY(-6px); box-shadow: 0 18px 35px rgba(0,0,0,0.5); }");
        out.println(".stat-icon { font-size: 40px; margin-bottom: 10px; }");
        out.println(".stat-number { font-size: 28px; font-weight: 700; }");
        out.println(".stat-label { font-size: 14px; opacity: 0.85; }");

        /* Logout button */
        out.println(".logout-btn { position:fixed; top:20px; right:20px; background:white; color:#07315c; padding:10px 18px; border-radius:12px; text-decoration:none; font-weight:600; }");
        out.println(".logout-btn:hover { background:#ddeaff; }");

        out.println("</style>");
        out.println("</head>");


        // BODY START
        out.println("<body>");

        // Logout
        out.println("<a class='logout-btn' href='AdminLogoutServlet'><i class='fas fa-sign-out-alt'></i> Logout</a>");

        // Header Banner
        out.println("<div class='header-banner'>");
        out.println("  <div class='header-title'><i class='fas fa-user-gear'></i> Admin Dashboard</div>");
        out.println("  <div class='welcome-text'>Welcome, <strong>" + escapeHtml(adminName) + "</strong><br>Manage and monitor your complete railway system here.</div>");
        out.println("</div>");

        // 4 Buttons Row
        out.println("<div class='button-row'>");
        out.println("  <a class='dash-btn' href='ViewTrainsServlet'><i class='fas fa-train'></i> Manage Trains</a>");
        out.println("  <a class='dash-btn' href='ViewScheduleServlet'><i class='fas fa-calendar-alt'></i> Manage Schedule</a>");
        out.println("  <a class='dash-btn' href='SeeReservationServlet'><i class='fas fa-ticket-alt'></i> Reservations</a>");
        out.println("  <a class='dash-btn' href='UserManagementServlet'><i class='fas fa-user-times'></i> Manage User</a>");
        out.println("</div>");

        // ⭐ NEW BOTTOM FULL-WIDTH ANALYTICS SECTION ⭐
        out.println("<div class='stats-container'>");
        out.println("<div class='stats-title'><i class='fas fa-chart-line'></i> System Overview & Quick Insights</div>");

        out.println("<div class='stats-grid'>");

        out.println("<div class='stat-box'>");
        out.println("<div class='stat-icon'><i class='fas fa-train'></i></div>");
        out.println("<div class='stat-number'>52</div>");
        out.println("<div class='stat-label'>Active Trains</div>");
        out.println("</div>");

        out.println("<div class='stat-box'>");
        out.println("<div class='stat-icon'><i class='fas fa-calendar-check'></i></div>");
        out.println("<div class='stat-number'>148</div>");
        out.println("<div class='stat-label'>Scheduled Routes</div>");
        out.println("</div>");

        out.println("<div class='stat-box'>");
        out.println("<div class='stat-icon'><i class='fas fa-users'></i></div>");
        out.println("<div class='stat-number'>3,920</div>");
        out.println("<div class='stat-label'>Registered Users</div>");
        out.println("</div>");

        out.println("<div class='stat-box'>");
        out.println("<div class='stat-icon'><i class='fas fa-ticket-alt'></i></div>");
        out.println("<div class='stat-number'>890</div>");
        out.println("<div class='stat-label'>Reservations Today</div>");
        out.println("</div>");

        out.println("</div>"); // grid end
        out.println("</div>"); // stats-container end

        out.println("</body>");
        out.println("</html>");
    }

    private String escapeHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#x27;");
    }
}
