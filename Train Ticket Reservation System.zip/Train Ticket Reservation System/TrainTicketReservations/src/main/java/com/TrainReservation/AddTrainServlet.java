package com.TrainReservation;

import com.util.DBConnection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/AddTrainServlet")
public class AddTrainServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");

        String trainNumber = request.getParameter("train_number");
        String trainName = request.getParameter("train_name");
        String source = request.getParameter("source");
        String destination = request.getParameter("destination");
        String departureTime = request.getParameter("departure_time"); // HH:mm
        String arrivalTime = request.getParameter("arrival_time");     // HH:mm
        int totalSeats = Integer.parseInt(request.getParameter("total_seats"));
        double fare = Double.parseDouble(request.getParameter("fare"));

        // Append ":00" to make it HH:mm:ss format
        if (!departureTime.contains(":")) departureTime += ":00:00";
        if (departureTime.length() == 5) departureTime += ":00";

        if (!arrivalTime.contains(":")) arrivalTime += ":00:00";
        if (arrivalTime.length() == 5) arrivalTime += ":00";

        try {
            Connection conn = DBConnection.getConnection();

            String sql = "INSERT INTO trains (train_number, train_name, source_station, destination_station, departure_time, arrival_time, total_seats, fare) " +
                         "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, trainNumber);
            ps.setString(2, trainName);
            ps.setString(3, source);
            ps.setString(4, destination);
            ps.setTime(5, Time.valueOf(departureTime));
            ps.setTime(6, Time.valueOf(arrivalTime));
            ps.setInt(7, totalSeats);
            ps.setDouble(8, fare);

            ps.executeUpdate();

            ps.close();
            conn.close();

            response.sendRedirect("ViewTrainsServlet");

        } catch (Exception e) {
            e.printStackTrace();
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h3 style='color:red;'>Error: " + e.getMessage() + "</h3>");
            out.println("<a href='add_train.html'>Back</a>");
            out.println("</body></html>");
        }
    }
}
