package com.TrainReservation;

import com.util.DBConnection;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/ViewUserDetailsServlet")
public class ViewUserDetailsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String userId = request.getParameter("user_id");
        if (userId == null) {
            out.println("<p class='text-danger'>Invalid user ID.</p>");
            return;
        }

        try {
            Connection conn = DBConnection.getConnection();
            String sql = "SELECT full_name, email, phone, created_at FROM users WHERE user_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(userId));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                out.println("<div class='user-details'>");
                out.println("<p><strong>Name:</strong> " + rs.getString("full_name") + "</p>");
                out.println("<p><strong>Email:</strong> " + rs.getString("email") + "</p>");
                out.println("<p><strong>Phone:</strong> " + rs.getString("phone") + "</p>");
                out.println("<p><strong>Registered:</strong> " + rs.getTimestamp("created_at") + "</p>");
                out.println("</div>");
            } else {
                out.println("<p class='text-danger'>User not found.</p>");
            }

            rs.close();
            ps.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
            out.println("<p class='text-danger'>Error: " + e.getMessage() + "</p>");
        }
    }
}
