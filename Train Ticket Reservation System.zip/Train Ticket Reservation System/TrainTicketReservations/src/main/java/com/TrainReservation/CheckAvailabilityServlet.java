package com.TrainReservation;

import com.util.DBConnection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/CheckAvailabilityServlet")
public class CheckAvailabilityServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String from = request.getParameter("from");
        String to = request.getParameter("to");
        String date = request.getParameter("date");

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Check Train Availability</title>");

        out.println("<style>");
        out.println("body { font-family: 'Segoe UI', sans-serif; background: #f0f4ff; padding: 40px; }");
        out.println(".container { max-width: 900px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 15px rgba(0,0,0,0.1);} ");
        out.println("h2 { text-align: center; color: #003366; margin-bottom: 30px; }");
        out.println("input, select { width: 100%; padding: 12px; margin-top: 10px; border-radius: 6px; border: 1px solid #ccc; }");
        out.println(".btn { padding: 12px 20px; background: #003366; color: white; border: none; border-radius: 6px; cursor: pointer; margin-top: 15px; width: 100%; font-size: 16px; }");
        out.println(".btn:hover { background: #002855; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-top: 30px; }");
        out.println("th, td { padding: 12px; border: 1px solid #ccc; text-align: center; }");
        out.println("th { background: #003366; color: white; }");
        out.println("tr:hover { background: #eef3ff; }");
        out.println(".book-btn { background: #28a745; padding: 8px 14px; color: white; border-radius: 5px; text-decoration: none; }");
        out.println(".book-btn:hover { background: #1e7e34; }");
        out.println("</style>");

        out.println("</head><body>");
        out.println("<div class='container'>");

        out.println("<h2>Check Train Availability</h2>");

        // ----- SEARCH FORM -----
        out.println("<form method='get' action='CheckAvailabilityServlet'>");

        out.println("<label>From:</label>");
        out.println("<input type='text' name='from' required value='" + (from != null ? from : "") + "'>");

        out.println("<label>To:</label>");
        out.println("<input type='text' name='to' required value='" + (to != null ? to : "") + "'>");

        out.println("<label>Travel Date:</label>");
        out.println("<input type='date' name='date' required value='" + (date != null ? date : "") + "'>");

        out.println("<button class='btn' type='submit'>Search Trains</button>");
        out.println("</form>");

        // --------------------------------------------------------
        // SHOW RESULTS IF USER HAS SEARCHED
        // --------------------------------------------------------

        if (from != null && to != null && date != null) {
            try {
                Connection conn = DBConnection.getConnection();

                String sql =
                        "SELECT t.train_id, t.train_number, t.train_name, t.source_station, t.destination_station, " +
                        "t.departure_time, t.arrival_time, t.fare, " +
                        "ts.schedule_id, ts.travel_date, ts.total_seats, " +
                        "COALESCE(SUM(b.seats_booked), 0) AS booked_seats, " +
                        "(ts.total_seats - COALESCE(SUM(b.seats_booked), 0)) AS available_seats " +
                        "FROM train_schedule ts " +
                        "JOIN trains t ON ts.train_id = t.train_id " +
                        "LEFT JOIN bookings b ON ts.schedule_id = b.schedule_id " +
                        "WHERE t.source_station = ? AND t.destination_station = ? AND ts.travel_date = ? " +
                        "GROUP BY t.train_id, t.train_number, t.train_name, t.source_station, " +
                        "t.destination_station, t.departure_time, t.arrival_time, t.fare, " +
                        "ts.schedule_id, ts.travel_date, ts.total_seats " +
                        "ORDER BY t.departure_time";

                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, from);
                ps.setString(2, to);
                ps.setDate(3, java.sql.Date.valueOf(date));

                ResultSet rs = ps.executeQuery();

                out.println("<table>");
                out.println("<tr>");
                out.println("<th>Train No</th><th>Train Name</th><th>From</th><th>To</th>");
                out.println("<th>Departure</th><th>Arrival</th><th>Fare</th>");
                out.println("<th>Available Seats</th><th>Action</th>");
                out.println("</tr>");

                boolean found = false;

                while (rs.next()) {
                    found = true;

                    out.println("<tr>");
                    out.println("<td>" + rs.getString("train_number") + "</td>");
                    out.println("<td>" + rs.getString("train_name") + "</td>");
                    out.println("<td>" + rs.getString("source_station") + "</td>");
                    out.println("<td>" + rs.getString("destination_station") + "</td>");
                    out.println("<td>" + rs.getString("departure_time") + "</td>");
                    out.println("<td>" + rs.getString("arrival_time") + "</td>");
                    out.println("<td>Rs. " + rs.getDouble("fare") + "</td>");
                    out.println("<td>" + rs.getInt("available_seats") + "</td>");

                    out.println("<td>");
                    out.println("<a href='user_login.html' class='book-btn'>Book</a>");
                    out.println("</td>");

                    out.println("</tr>");
                }

                if (!found) {
                    out.println("<tr><td colspan='9' style='color:red;'>No trains found.</td></tr>");
                }

                out.println("</table>");

                rs.close();
                ps.close();
                conn.close();

            } catch (Exception e) {
                out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            }
        }

        out.println("</div>");
        out.println("</body></html>");
    }
}
