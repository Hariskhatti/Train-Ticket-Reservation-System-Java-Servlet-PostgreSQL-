package com.TrainReservation;

import com.util.DBConnection;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet("/UserAccountServlet")
public class UserAccountServlet extends HttpServlet {

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                .replace("\"","&quot;").replace("'","&#x27;");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        res.setContentType("text/html");
        PrintWriter out = res.getWriter();

        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user_id") == null) {
            res.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) session.getAttribute("user_id");
        String msg = req.getParameter("msg");

        try (Connection conn = DBConnection.getConnection()) {

            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM users WHERE user_id=?"
            );
            ps.setInt(1, userId);
            ResultSet r = ps.executeQuery();

            if (!r.next()) {
                out.println("User not found!");
                return;
            }

            out.println("<html><head><title>User Profile</title><style>");

            out.println("body{font-family:Segoe UI;background:#eef3ff;padding:40px;}");
            out.println(".container{max-width:600px;margin:auto;background:white;padding:30px;"
                     + "border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,0.15);} ");
            out.println("h2{text-align:center;color:#003366;margin-bottom:25px;}");

            out.println("label{font-weight:600;}");
            out.println("input{width:100%;padding:12px;border-radius:6px;"
                     + "border:1px solid #bbb;margin-top:5px;margin-bottom:18px;font-size:15px;}");

            out.println("button{background:#003366;color:white;padding:14px;width:100%;border:none;"
                     + "border-radius:6px;font-size:16px;cursor:pointer;} ");
            out.println("button:hover{background:#002655;}");

            out.println(".msg-success{color:green;text-align:center;font-weight:bold;margin-bottom:15px;}");
            out.println(".msg-error{color:red;text-align:center;font-weight:bold;margin-bottom:15px;}");

            out.println("</style></head><body>");

            out.println("<div class='container'>");

            if ("success".equals(msg))
                out.println("<div class='msg-success'>Profile Updated Successfully!</div>");
            if ("pass_mismatch".equals(msg))
                out.println("<div class='msg-error'>Passwords Do Not Match!</div>");

            out.println("<h2>Your Profile</h2>");

            // =========================
            //   SINGLE FULL FORM
            // =========================
            out.println("<form method='post' action='UserAccountServlet'>");

            out.println("<label>Full Name</label>");
            out.println("<input name='full_name' value='" + escape(r.getString("full_name")) + "' required>");

            out.println("<label>Email</label>");
            out.println("<input type='email' name='email' value='" + escape(r.getString("email")) + "' required>");

            out.println("<label>Phone</label>");
            out.println("<input name='phone' value='" + escape(r.getString("phone")) + "' required>");

            out.println("<label>New Password (Optional)</label>");
            out.println("<input type='password' name='password'>");

            out.println("<label>Confirm Password</label>");
            out.println("<input type='password' name='confirm_password'>");

            out.println("<button type='submit'>Save Changes</button>");

            out.println("</form>");

            out.println("<br><a href='UserDashboardServlet' "
                    + "style='display:block;text-align:center;background:#003366;color:white;"
                    + "padding:12px;border-radius:6px;text-decoration:none;'>Back to Dashboard</a>");

            out.println("</div></body></html>");

        } catch (Exception e) {
            res.getWriter().println("Error: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        HttpSession s = req.getSession(false);
        if (s == null || s.getAttribute("user_id") == null) {
            res.sendRedirect("user_login.html");
            return;
        }

        int userId = (int) s.getAttribute("user_id");

        String name = req.getParameter("full_name");
        String email = req.getParameter("email");
        String phone = req.getParameter("phone");
        String pass = req.getParameter("password");
        String cpass = req.getParameter("confirm_password");

        try (Connection conn = DBConnection.getConnection()) {

            if (pass != null && !pass.trim().isEmpty()) {
                if (!pass.equals(cpass)) {
                    res.sendRedirect("UserAccountServlet?msg=pass_mismatch");
                    return;
                }

                PreparedStatement ps = conn.prepareStatement(
                    "UPDATE users SET full_name=?, email=?, phone=?, password=? WHERE user_id=?"
                );
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, pass);
                ps.setInt(5, userId);
                ps.executeUpdate();

            } else {
                PreparedStatement ps = conn.prepareStatement(
                    "UPDATE users SET full_name=?, email=?, phone=? WHERE user_id=?"
                );
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setInt(4, userId);
                ps.executeUpdate();
            }

            res.sendRedirect("UserAccountServlet?msg=success");

        } catch (Exception e) {
            res.getWriter().println("Error: " + e.getMessage());
        }
    }
}
