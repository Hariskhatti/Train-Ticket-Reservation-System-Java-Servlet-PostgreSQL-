package com.TrainReservation;

import com.util.DBConnection;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;

@WebServlet("/UserRegisterServlet")
public class UserRegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String fullName = request.getParameter("full_name").trim();
        String email = request.getParameter("email").trim();
        String password = request.getParameter("password").trim();
        String phone = request.getParameter("phone").trim();

        try {
            Connection conn = DBConnection.getConnection();

            // Check if email already exists
            String checkQuery = "SELECT user_id FROM users WHERE email = ?";
            PreparedStatement checkPs = conn.prepareStatement(checkQuery);
            checkPs.setString(1, email);
            ResultSet rs = checkPs.executeQuery();

            if (rs.next()) {
                // Email already registered
                showMessage(out, "Email already registered! Try logging in.", false);
                rs.close();
                checkPs.close();
                conn.close();
                return;
            }

            rs.close();
            checkPs.close();

            // Insert new user
            String insertQuery = "INSERT INTO users (full_name, email, password, phone) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(insertQuery);
            ps.setString(1, fullName);
            ps.setString(2, email);
            ps.setString(3, password);  // Optional: Hash password for security
            ps.setString(4, phone);

            int result = ps.executeUpdate();
            ps.close();
            conn.close();

            if (result > 0) {
                showMessage(out, "Registered Successfully!", true);
            } else {
                showMessage(out, "Registration failed. Please try again.", false);
            }

        } catch (Exception e) {
            e.printStackTrace();
            showMessage(out, "Error: " + e.getMessage(), false);
        }
    }

    private void showMessage(PrintWriter out, String message, boolean success) {
        out.println("<html><head><title>Registration Result</title>");
        out.println("<script>");
        out.println("alert('" + message.replace("'", "\\'") + "');");
        if (success) {
            out.println("window.location = 'user_login.html';");
        } else {
            out.println("window.location = 'user_register.html';");
        }
        out.println("</script>");
        out.println("</head><body></body></html>");
    }
}
